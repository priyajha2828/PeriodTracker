import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:myperioddiary/ProfilePage/EditProfile.dart';

// Mock user data and history; replace with your DB fetch logic
const Color babyPink = Color(0xFFFFB6C1);
const Color babyPinkLight = Color(0xFFFFD7E0);
const Color textDark = Color(0xFF502E32);
const Color textLight = Color(0xFF83334C);

void main() {
  runApp(const MyPeriodDiaryProfileApp());
}

/// Entry point app widget
class MyPeriodDiaryProfileApp extends StatelessWidget {
  const MyPeriodDiaryProfileApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'User Profile - MyPeriodDiary',
      theme: ThemeData(
        scaffoldBackgroundColor: babyPink,
        fontFamily: 'Segoe UI',
        primaryColor: babyPink,
        textTheme: const TextTheme(
          bodyMedium: TextStyle(color: textDark, fontSize: 16),
          titleLarge: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
          headlineSmall: TextStyle(
            color: babyPink,
            fontWeight: FontWeight.w700,
            fontSize: 28,
          ),
        ),
      ),
      home: const ProfilePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key}) : super(key: key);

  // Dummy user info - replace with your dynamic data loading
  final String userName = 'priya kumari jha';
  final String avatarUrl =
      ''; // Provide your avatar URL or use AssetImage

  // Dummy history data as would be fetched from your DB
  final List<Map<String, dynamic>> historyRecords = const [
    {
      'profileID': 1001,
      'question': 'Do you exercise regularly?',
      'answer': 'Yes, 3 times a week',
      'cycle_start_date': '2025-07-12',
      'cycle_end_date': '2025-07-18',
      'ovulation_date': '2025-07-26',
      'fertile_window': '2025-07-22 to 2025-07-27',
      'flow_intensity': 'Medium',
      'status': 'current',
    },
    {
      'profileID': 998,
      'question': 'Have you had irregular cycles?',
      'answer': 'No',
      'cycle_start_date': '2025-06-10',
      'cycle_end_date': '2025-06-16',
      'ovulation_date': '2025-06-24',
      'fertile_window': '2025-06-20 to 2025-06-25',
      'flow_intensity': 'Light',
      'status': 'absolute',
    },
    // Add more records as needed
  ];

  String formatDate(String? dateStr) {
    if (dateStr == null || dateStr.isEmpty) return '-';
    try {
      final dt = DateTime.parse(dateStr);
      return DateFormat('yyyy-MM-dd').format(dt);
    } catch (_) {
      return '-';
    }
  }

  Color statusColor(String status) {
    return status == 'current' ? const Color(0xFFFFADC0) : const Color(0xFFFFCDD7);
  }

  Color statusTextColor(String status) {
    return status == 'current' ? const Color(0xFF5B1223) : const Color(0xFF84342E);
  }

  @override
  Widget build(BuildContext context) {
    final maxContentWidth = 720.0;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
          child: Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: maxContentWidth),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Header ONLY with username, no "Next" button
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Text(
                      'Welcome, $userName',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 30,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Profile card
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.pinkAccent.withOpacity(0.3),
                          blurRadius: 25,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 32),
                    margin: const EdgeInsets.only(bottom: 28),
                    child: LayoutBuilder(
                      builder: (context, constraints) {
                        final isMobile = constraints.maxWidth < 600;
                        return Flex(
                          direction: isMobile ? Axis.vertical : Axis.horizontal,
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: isMobile
                              ? CrossAxisAlignment.center
                              : CrossAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ClipOval(
                              child: Image.network(
                                avatarUrl,
                                width: 120,
                                height: 120,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return Container(
                                    width: 120,
                                    height: 120,
                                    color: babyPinkLight,
                                    child: Icon(Icons.person,
                                        size: 80, color: babyPink),
                                  );
                                },
                              ),
                            ),
                            SizedBox(width: isMobile ? 0 : 20, height: isMobile ? 20 : 0),
                            Flexible(
                              child: Text(
                                userName,
                                textAlign: isMobile ? TextAlign.center : TextAlign.left,
                                style: const TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.w700,
                                  color: textDark,
                                ),
                              ),
                            ),
                            SizedBox(width: isMobile ? 0 : 20, height: isMobile ? 20 : 0),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: babyPink,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 24, vertical: 14),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                elevation: 6,
                                shadowColor: Colors.pinkAccent.withOpacity(0.5),
                                textStyle: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                ),
                              ),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => const EditProfileApp()),
                                );
                              },


                              child: const Text('Edit Profile'),
                            ),
                          ],
                        );
                      },
                    ),
                  ),

                  // History section
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.pinkAccent.withOpacity(0.2),
                          blurRadius: 24,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'User History',
                          style: TextStyle(
                            color: babyPink,
                            fontWeight: FontWeight.w700,
                            fontSize: 26,
                            decoration: TextDecoration.underline,
                            decorationColor: babyPinkLight,
                            decorationThickness: 3,
                          ),
                        ),
                        const SizedBox(height: 12),

                        historyRecords.isEmpty
                            ? const Padding(
                          padding: EdgeInsets.symmetric(vertical: 20),
                          child: Text(
                            'No history records found.',
                            style: TextStyle(fontStyle: FontStyle.italic, fontSize: 16),
                          ),
                        )
                            : SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: DataTable(
                            headingRowColor: MaterialStateProperty.all(babyPinkLight),
                            headingTextStyle: TextStyle(
                              color: textDark,
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                            dataTextStyle: TextStyle(
                              color: textDark,
                              fontSize: 14,
                            ),
                            columns: const [
                              DataColumn(label: Text('Profile ID')),
                              DataColumn(label: Text('Question')),
                              DataColumn(label: Text('Answer')),
                              DataColumn(label: Text('Cycle Start Date')),
                              DataColumn(label: Text('Cycle End Date')),
                              DataColumn(label: Text('Ovulation Date')),
                              DataColumn(label: Text('Fertile Window')),
                              DataColumn(label: Text('Flow Intensity')),
                              DataColumn(label: Text('Status')),
                            ],
                            rows: historyRecords.map((record) {
                              final status = record['status'] ?? '-';
                              return DataRow(
                                cells: [
                                  DataCell(Text(record['profileID'].toString())),
                                  DataCell(Text(record['question'] ?? '-')),
                                  DataCell(Text(record['answer'] ?? '-')),
                                  DataCell(Text(formatDate(record['cycle_start_date']))),
                                  DataCell(Text(formatDate(record['cycle_end_date']))),
                                  DataCell(Text(formatDate(record['ovulation_date']))),
                                  DataCell(Text(record['fertile_window'] ?? '-')),
                                  DataCell(Text(record['flow_intensity'] ?? '-')),
                                  DataCell(Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: statusColor(status),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Text(
                                      status.toString(),
                                      style: TextStyle(
                                        color: statusTextColor(status),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14,
                                        textBaseline: TextBaseline.alphabetic,
                                      ),
                                    ),
                                  )),
                                ],
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
