import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() {
  runApp(const EditProfileApp());
}

class EditProfileApp extends StatelessWidget {
  const EditProfileApp({Key? key}) : super(key: key);

  static const Color babyPink = Color(0xFFFFB6C1);
  static const Color babyPinkLight = Color(0xFFFFD7E0);
  static const Color textDark = Color(0xFF502E32);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Edit Profile - MyPeriodDiary',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: babyPink,
        fontFamily: 'Segoe UI',
        primaryColor: babyPink,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: babyPinkLight,
          contentPadding:
          const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: babyPink),
          ),
          hintStyle: TextStyle(color: textDark.withOpacity(0.5)),
        ),
        checkboxTheme: CheckboxThemeData(
          fillColor: MaterialStateProperty.all(babyPink),
        ),
        textTheme: const TextTheme(
          bodyMedium: TextStyle(color: textDark, fontSize: 16),
          titleLarge: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 24),
        ),
      ),
      home: const EditProfilePage(),
    );
  }
}

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({Key? key}) : super(key: key);

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  static const babyPink = Color(0xFFFFB6C1);
  static const babyPinkLight = Color(0xFFFFD7E0);
  static const textDark = Color(0xFF502E32);

  final _formKey = GlobalKey<FormState>();

  // Avatar related
  File? _avatarFile;
  final ImagePicker _picker = ImagePicker();

  // Form fields (initially empty or defaults)
  late TextEditingController _firstNameController;
  late TextEditingController _middleNameController;
  late TextEditingController _lastNameController;
  late TextEditingController _nameController;
  late TextEditingController _dobController;
  late TextEditingController _emailController;
  int _heightFeet = 5;
  int _heightInches = 0;
  late TextEditingController _weightController;
  late TextEditingController _allergiesController;
  late TextEditingController _lastPeriodController;
  int _periodLength = 5;
  int _cycleLength = 28;
  late TextEditingController _irregularityController;
  List<String> _symptoms = [];
  late TextEditingController _medicationsController;
  late TextEditingController _activityController;
  late TextEditingController _notesController;
  List<String> _notifications = [];
  late TextEditingController _customReminderController;

  // Options for symptoms and notifications (example from PHP)
  static const List<String> symptomsOptions = [
    'Pain',
    'Bloating',
    'Mood swings',
    'Headache',
    'Fatigue',
  ];

  static const List<String> notificationsOptions = [
    'Reminders',
    'Appointments',
    'Medication',
    'Notes',
  ];

  @override
  void initState() {
    super.initState();

    // Initialize controllers with empty or default values
    _firstNameController = TextEditingController();
    _middleNameController = TextEditingController();
    _lastNameController = TextEditingController();
    _nameController = TextEditingController();
    _dobController = TextEditingController();
    _emailController = TextEditingController();
    _weightController = TextEditingController();
    _allergiesController = TextEditingController();
    _lastPeriodController = TextEditingController();
    _irregularityController = TextEditingController();
    _medicationsController = TextEditingController();
    _activityController = TextEditingController();
    _notesController = TextEditingController();
    _customReminderController = TextEditingController();

    // TODO: Load actual data from backend and update controllers & lists
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _middleNameController.dispose();
    _lastNameController.dispose();
    _nameController.dispose();
    _dobController.dispose();
    _emailController.dispose();
    _weightController.dispose();
    _allergiesController.dispose();
    _lastPeriodController.dispose();
    _irregularityController.dispose();
    _medicationsController.dispose();
    _activityController.dispose();
    _notesController.dispose();
    _customReminderController.dispose();
    super.dispose();
  }

  Future<void> _pickAvatar() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        _avatarFile = File(image.path);
      });
    }
  }

  void _toggleSymptom(String symptom) {
    setState(() {
      if (_symptoms.contains(symptom)) {
        _symptoms.remove(symptom);
      } else {
        _symptoms.add(symptom);
      }
    });
  }

  void _toggleNotification(String notification) {
    setState(() {
      if (_notifications.contains(notification)) {
        _notifications.remove(notification);
      } else {
        _notifications.add(notification);
      }
    });
  }

  // Date picker helpers
  Future<void> _selectDate(
      BuildContext context, TextEditingController controller) async {
    DateTime? initialDate;
    try {
      initialDate = DateTime.parse(controller.text);
    } catch (_) {
      initialDate = DateTime.now();
    }
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initialDate ?? DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      controller.text = picked.toIso8601String().substring(0, 10);
    }
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      // TODO: Send data to backend API here (including _avatarFile if updated)
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Profile saved successfully!'),
      ));
    }
  }

  Widget _buildMultiSelectChips(
      List<String> options, List<String> selectedValues, Function(String) toggle) {
    return Wrap(
      spacing: 10,
      runSpacing: 6,
      children: options.map((option) {
        final selected = selectedValues.contains(option);
        return FilterChip(
          label: Text(option),
          selected: selected,
          selectedColor: babyPink,
          onSelected: (_) => toggle(option),
          labelStyle: TextStyle(
            color: selected ? Colors.white : babyPink,
            fontWeight: FontWeight.bold,
          ),
          checkmarkColor: Colors.white,
          backgroundColor: babyPinkLight,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final horizontalPadding = MediaQuery.of(context).size.width < 600 ? 16.0 : 32.0;
    final maxContentWidth = 700.0;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: horizontalPadding, vertical: 20),
          child: Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: maxContentWidth),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    Text(
                      'Edit Profile',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 18),

                    // Avatar picker & preview
                    GestureDetector(
                      onTap: _pickAvatar,
                      child: CircleAvatar(
                        radius: 70,
                        backgroundColor: babyPinkLight,
                        backgroundImage: _avatarFile != null
                            ? FileImage(_avatarFile!)
                            : const AssetImage('assets/profile_avatar.png')
                        as ImageProvider,
                        child: Align(
                          alignment: Alignment.bottomRight,
                          child: Container(
                            decoration: BoxDecoration(
                              color: babyPink,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                            padding: const EdgeInsets.all(6),
                            child: const Icon(
                              Icons.edit,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Full Name Fields
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Full Name',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 20,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: _firstNameController,
                            decoration: const InputDecoration(
                              labelText: 'First Name',
                            ),
                            validator: (v) =>
                            (v ?? '').trim().isEmpty ? 'Required field' : null,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: TextFormField(
                            controller: _middleNameController,
                            decoration: const InputDecoration(
                              labelText: 'Middle Name',
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: TextFormField(
                            controller: _lastNameController,
                            decoration: const InputDecoration(
                              labelText: 'Last Name',
                            ),
                            validator: (v) =>
                            (v ?? '').trim().isEmpty ? 'Required field' : null,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Personal Details (DOB & Email)
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Personal Details',
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 20,
                            color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: _dobController,
                            readOnly: true,
                            decoration: InputDecoration(
                              labelText: 'Date of Birth',
                              suffixIcon: IconButton(
                                icon: const Icon(Icons.calendar_today),
                                onPressed: () => _selectDate(context, _dobController),
                              ),
                            ),
                            validator: (v) {
                              if (v == null || v.isEmpty) return null;
                              try {
                                DateTime.parse(v);
                                return null;
                              } catch (_) {
                                return 'Invalid date';
                              }
                            },
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: TextFormField(
                            controller: _emailController,
                            decoration: const InputDecoration(labelText: 'Email Address'),
                            keyboardType: TextInputType.emailAddress,
                            validator: (v) {
                              if (v == null || v.isEmpty) return null;
                              final emailRegex = RegExp(
                                  r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@"
                                  r"[a-zA-Z0-9]+(?:\.[a-zA-Z0-9-]+)*$");
                              if (!emailRegex.hasMatch(v)) return 'Invalid email';
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Physical Attributes
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Physical Attributes',
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 20,
                            color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 16,
                      runSpacing: 16,
                      children: [
                        SizedBox(
                          width: 110,
                          child: InputDecorator(
                            decoration: InputDecoration(
                              labelText: 'Height (Feet)',
                              filled: true,
                              fillColor: babyPinkLight,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide.none,
                              ),
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<int>(
                                value: _heightFeet,
                                isExpanded: true,
                                items: List.generate(
                                    5,
                                        (index) => index + 3) // from 3 to 7 feet
                                    .map((e) => DropdownMenuItem(
                                  value: e,
                                  child: Text('$e ft'),
                                ))
                                    .toList(),
                                onChanged: (val) {
                                  if (val != null) {
                                    setState(() {
                                      _heightFeet = val;
                                    });
                                  }
                                },
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 110,
                          child: InputDecorator(
                            decoration: InputDecoration(
                              labelText: 'Height (Inches)',
                              filled: true,
                              fillColor: babyPinkLight,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide.none,
                              ),
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<int>(
                                value: _heightInches,
                                isExpanded: true,
                                items: List.generate(12, (index) => index)
                                    .map((e) => DropdownMenuItem(
                                  value: e,
                                  child: Text('$e in'),
                                ))
                                    .toList(),
                                onChanged: (val) {
                                  if (val != null) {
                                    setState(() {
                                      _heightInches = val;
                                    });
                                  }
                                },
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 140,
                          child: TextFormField(
                            controller: _weightController,
                            keyboardType:
                            const TextInputType.numberWithOptions(decimal: true),
                            decoration: const InputDecoration(
                              labelText: 'Weight (kg)',
                              hintText: 'e.g. 62.5',
                            ),
                            validator: (v) {
                              if (v == null || v.isEmpty) return null;
                              final weight = double.tryParse(v);
                              if (weight == null || weight < 20 || weight > 300) {
                                return '20 to 300 kg allowed';
                              }
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _allergiesController,
                      decoration: const InputDecoration(
                        labelText: 'Allergies or Medical Conditions',
                        alignLabelWithHint: true,
                      ),
                      maxLines: null,
                      minLines: 3,
                      keyboardType: TextInputType.multiline,
                    ),

                    const SizedBox(height: 24),

                    // Cycle Information
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Cycle Information',
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 20,
                            color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _lastPeriodController,
                      readOnly: true,
                      decoration: InputDecoration(
                        labelText: 'Date of Last Menstrual Period',
                        filled: true,
                        fillColor: babyPinkLight,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                        suffixIcon: IconButton(
                          icon: const Icon(Icons.calendar_today),
                          onPressed: () => _selectDate(context, _lastPeriodController),
                        ),
                      ),
                      validator: (v) {
                        if (v == null || v.isEmpty) return null;
                        try {
                          DateTime.parse(v);
                          return null;
                        } catch (_) {
                          return 'Invalid date';
                        }
                      },
                    ),

                    const SizedBox(height: 8),

                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            initialValue: null,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Average Period Length (days)',
                              filled: true,
                              fillColor: babyPinkLight,
                              border: InputBorder.none,
                            ),
                            controller: TextEditingController(
                                text: '$_periodLength'), // This is just snapshot, consider better state in real code
                            onChanged: (v) {
                              final val = int.tryParse(v);
                              if (val != null) {
                                setState(() => _periodLength = val);
                              }
                            },
                          ),
                        ),
                        const SizedBox(width: 20),
                        Expanded(
                          child: TextFormField(
                            initialValue: null,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Average Cycle Length (days)',
                              filled: true,
                              fillColor: babyPinkLight,
                              border: InputBorder.none,
                            ),
                            controller: TextEditingController(
                                text: '$_cycleLength'), // Snapshot only
                            onChanged: (v) {
                              final val = int.tryParse(v);
                              if (val != null) {
                                setState(() => _cycleLength = val);
                              }
                            },
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 8),

                    TextFormField(
                      controller: _irregularityController,
                      decoration: const InputDecoration(labelText: 'Irregularity Information'),
                    ),

                    const SizedBox(height: 24),

                    // Symptoms multi-select chips
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Symptoms',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 20,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildMultiSelectChips(
                        EditProfilePageStateHolder.symptomsOptions, _symptoms, _toggleSymptom),

                    const SizedBox(height: 24),

                    // Medications
                    TextFormField(
                      controller: _medicationsController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Medications or Contraceptive Use',
                        alignLabelWithHint: true,
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Activity / notes
                    TextFormField(
                      controller: _activityController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Activity Logs / Notes',
                        alignLabelWithHint: true,
                      ),
                    ),

                    const SizedBox(height: 24),

                    TextFormField(
                      controller: _notesController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Additional Notes',
                        alignLabelWithHint: true,
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Notifications multi-select chips
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Notifications',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 20,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildMultiSelectChips(
                        EditProfilePageStateHolder.notificationsOptions,
                        _notifications,
                        _toggleNotification),

                    const SizedBox(height: 24),

                    // Custom Reminder
                    TextFormField(
                      controller: _customReminderController,
                      decoration: const InputDecoration(
                        labelText: 'Custom Reminder Schedule',
                        hintText: 'E.g. Water intake reminders at 9 AM',
                      ),
                    ),

                    const SizedBox(height: 32),

                    // Submit Button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: babyPink,
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(24),
                          ),
                          textStyle: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                          elevation: 8,
                        ),
                        onPressed: _submitForm,
                        child: const Text('Save Profile'),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// Helper class to hold static option lists (to avoid redeclaring in the widget)
class EditProfilePageStateHolder {
  static const symptomsOptions = [
    'Pain',
    'Bloating',
    'Mood swings',
    'Headache',
    'Fatigue',
  ];

  static const notificationsOptions = [
    'Reminders',
    'Appointments',
    'Medication',
    'Notes',
  ];
}
