import 'package:flutter/material.dart';
import '../LandingPage/landing.dart';

// Entry point
void main() {
  runApp(MyPeriodDiaryApp());
}

class MyPeriodDiaryApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyPeriodDiary - Food Recipes',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: babyPinkDark,
        scaffoldBackgroundColor: babyPink,
        fontFamily: 'Segoe UI', // Close to your CSS fonts
        textTheme: TextTheme(
          titleLarge: TextStyle(
            color: babyPinkDark,
            fontWeight: FontWeight.bold,
          ),
          bodyMedium: TextStyle(
            color: textMuted,
          ),
        ),

      ),
      home: FoodRecipesScreen(),
    );
  }
}

// Colors defined as per CSS variables
const Color babyPink = Color(0xFFFFB6C1);
const Color babyPinkDark = Color(0xFFE06A85);
const Color white = Colors.white;
const Color textDark = Color(0xFF3A1F2E);
const Color textMuted = Color(0xFF6B4A62);

class FoodRecipesScreen extends StatefulWidget {
  @override
  _FoodRecipesScreenState createState() => _FoodRecipesScreenState();
}

class _FoodRecipesScreenState extends State<FoodRecipesScreen> {
  // Simulate fetched recipes, grouped by day
  // Replace this with your real data source logic
  Map<String, List<Recipe>> recipesByDay = {};

  @override
  void initState() {
    super.initState();
    loadRecipes();
  }

  void loadRecipes() {
    // Simulated fetched and grouped data (matching your PHP grouping)
    // Normally, this comes from an API/database

    final List<Recipe> allRecipes = [
      Recipe(title: "Oatmeal with Berries", description: "Healthy oatmeal with fresh berries and honey."),
      Recipe(title: "Leafy Green Salad", description: "Mix spinach, kale with nuts and vinaigrette."),
      Recipe(title: "Day 1: Quinoa Bowl", description: "Quinoa, chickpeas, and steamed veggies."),
      Recipe(title: "Day 1: Herbal Tea", description: "A cup of ginger and lemon tea to soothe cramps."),
      Recipe(title: "Day 2: Smoothie", description: "Blend banana, spinach, and protein powder."),
      Recipe(title: "Day 3: Lentil Soup", description: "Warm lentil soup with carrots and celery."),
      Recipe(title: "Day 3: Dark Chocolate", description: "A small square of dark chocolate."),
      Recipe(title: "Energy Bites", description: "No bake oats and dates energy balls."),
    ];

    Map<String, List<Recipe>> grouped = {};

    for (var recipe in allRecipes) {
      final dayMatch = RegExp(r'^(Day \d+):\s*').firstMatch(recipe.title);
      if (dayMatch != null) {
        String dayKey = dayMatch.group(1)!; // e.g. "Day 1"
        String cleanTitle = recipe.title.replaceFirst(RegExp(r'^(Day \d+):\s*'), '');

        grouped.putIfAbsent(dayKey, () => []);
        grouped[dayKey]!.add(Recipe(title: cleanTitle, description: recipe.description));
      } else {
        grouped.putIfAbsent('Other', () => []);
        grouped['Other']!.add(recipe);
      }
    }

    setState(() {
      recipesByDay = grouped;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'MyPeriodDiary: Food Recipes',
          style: TextStyle(
            color: white,
            fontWeight: FontWeight.w700,
            fontSize:  20,
            shadows: [Shadow(color: Colors.black26, offset: Offset(0, 1), blurRadius: 1)],
          ),
        ),
        backgroundColor: babyPink,
        elevation: 2,
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12.0),
            child: TextButton.icon(
              style: TextButton.styleFrom(
                foregroundColor: white,
                backgroundColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6),
                ),
                padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              ).copyWith(
                overlayColor: MaterialStateProperty.all(Color(0xFFFF99B2)),
              ),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const RootPage()));
              },
              label: Text(
                'Back',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              icon: Icon(Icons.arrow_forward, size: 16),
            ),
          ),
        ],
        toolbarHeight: 56,
      ),
      body: recipesByDay.isEmpty
          ? Center(
        child: Text(
          'No recipes found.',
          style: TextStyle(
            fontStyle: FontStyle.italic,
            color: textMuted,
            fontSize: 16,
          ),
          textAlign: TextAlign.center,
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16),
        itemCount: recipesByDay.length,
        itemBuilder: (context, index) {
          String day = recipesByDay.keys.elementAt(index);
          List<Recipe> dayRecipes = recipesByDay[day]!;

          return RecipeDaySection(day: day, recipes: dayRecipes);
        },
      ),
    );
  }
}

class RecipeDaySection extends StatelessWidget {
  final String day;
  final List<Recipe> recipes;

  const RecipeDaySection({required this.day, required this.recipes});

  @override
  Widget build(BuildContext context) {
    // Generate a semantic label & id for accessibility like PHP aria-labelledby
    String sectionId = day.toLowerCase().replaceAll(' ', '-');

    return Semantics(
      container: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: day == 'Other' ? 8 : 28),
          Text(
            day,
            key: ValueKey(sectionId),
            style: TextStyle(
              color: babyPinkDark,
              fontSize: 22,
              fontWeight: FontWeight.bold,
              decoration: day != 'Other' ? TextDecoration.underline : TextDecoration.none,
              decorationColor: babyPink,
              decorationThickness: 2,
              decorationStyle: TextDecorationStyle.solid,
            ),
          ),
          ...recipes.map((recipe) => RecipeCard(recipe: recipe)).toList(),
        ],
      ),
    );
  }
}

class RecipeCard extends StatelessWidget {
  final Recipe recipe;

  const RecipeCard({required this.recipe});

  @override
  Widget build(BuildContext context) {
    return FocusableActionDetector(
      mouseCursor: SystemMouseCursors.click,
      child: Semantics(
        container: true,
        child: Card(
          margin: EdgeInsets.symmetric(vertical: 6),
          elevation: 1.5,
          shadowColor: babyPink.withOpacity(0.4),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 14.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  recipe.title,
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 18,
                    color: babyPinkDark,
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  recipe.description,
                  style: TextStyle(
                    fontSize: 15,
                    color: textMuted,
                    height: 1.3,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class Recipe {
  final String title;
  final String description;

  Recipe({required this.title, required this.description});
}
