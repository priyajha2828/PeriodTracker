import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/login_controller.dart';
import '../../signup/ui/signup_screen.dart';
import '../../user_questions/ui/user_questions.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final LoginController loginController = Get.put(LoginController());
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  late bool passwordVisible;

  final TextEditingController identifierController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    passwordVisible = true;
  }

  @override
  void dispose() {
    identifierController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  // Simple regex for email validation
  bool _isValidEmail(String input) {
    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    return emailRegex.hasMatch(input);
  }

  // Simple regex for phone validation (basic)
  bool _isValidPhone(String input) {
    final phoneRegex = RegExp(r'^\+?\d{7,15}$');
    return phoneRegex.hasMatch(input);
  }

  Future<void> _showForgetPasswordDialog() async {
    final TextEditingController contactController = TextEditingController();
    final _formForgetKey = GlobalKey<FormState>();
    bool isSending = false;

    await showDialog(
      context: context,
      barrierDismissible: false, // force action
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) => AlertDialog(
            title: const Text('Forget Password'),
            content: Form(
              key: _formForgetKey,
              child: TextFormField(
                controller: contactController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'Email or Phone',
                  hintText: 'Enter your registered email or phone number',
                  border: OutlineInputBorder(),
                ),
                validator: (val) {
                  if (val == null || val.trim().isEmpty) {
                    return 'Please enter your email or phone';
                  }
                  if (!_isValidEmail(val) && !_isValidPhone(val)) {
                    return 'Enter valid email or phone number';
                  }
                  return null;
                },
              ),
            ),
            actions: [
              TextButton(
                onPressed: isSending ? null : () {
                  Navigator.pop(context);
                },
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: isSending ? null : () async {
                  if (_formForgetKey.currentState!.validate()) {
                    setStateDialog(() => isSending = true);

                    // TODO: Implement your actual OTP sending logic here based on email or phone.
                    // For demonstration, we just wait 2 seconds then show success.
                    await Future.delayed(const Duration(seconds: 2));

                    setStateDialog(() => isSending = false);

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                            'OTP sent to ${contactController.text.trim()}'),
                        backgroundColor: Colors.green,
                      ),
                    );

                    Navigator.pop(context);
                  }
                },
                child: isSending
                    ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
                    : const Text('Send OTP'),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Login")),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          children: [
            const SizedBox(height: 20),
            Image.asset(
              "assets/images/3.png",
              height: 200,
              fit: BoxFit.contain,
            ),
            const SizedBox(height: 80),

            // Email or Phone Field
            TextFormField(
              controller: identifierController,
              decoration: InputDecoration(
                labelText: "Email or Phone",
                prefixIcon: const Icon(Icons.person_outline),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return 'Please enter your email or phone';
                }
                // Optional: add format validation here if you want
                return null;
              },
            ),

            const SizedBox(height: 20),

            // Password Field
            TextFormField(
              controller: passwordController,
              obscureText: passwordVisible,
              decoration: InputDecoration(
                labelText: "Password",
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: IconButton(
                  icon: Icon(passwordVisible
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined),
                  onPressed: () {
                    setState(() {
                      passwordVisible = !passwordVisible;
                    });
                  },
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              validator: (val) {
                if (val == null || val.isEmpty) {
                  return 'Please enter password';
                }
                return null;
              },
            ),

            // Added "Forget Password?" button
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: _showForgetPasswordDialog,
                child: const Text(
                  "Forget Password?",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    decoration: TextDecoration.underline,
                    color: Colors.blueAccent,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // LOGIN BUTTON
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  // Your login logic here, or directly redirect for now
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const UserQuestionsScreen(),
                    ),
                  );
                }
              },
              child: const Text("Login"),
            ),

            // SKIP LOGIN as TextButton (no background)
            TextButton(
              onPressed: () {
                // Anonymous login: direct redirect
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const UserQuestionsScreen(),
                  ),
                );
              },
              child: const Text(
                "Skip Login",
                style: TextStyle(
                  fontSize: 16,
                  decoration: TextDecoration.underline,
                  color: Colors.blue, // Optional color
                ),
              ),
            ),

            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("Don't have an account yet?"),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const SignUpScreen(),
                      ),
                    );
                  },
                  child: const Text("Sign Up"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
