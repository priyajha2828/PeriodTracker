import 'package:get/get.dart';

class LoginController extends GetxController {
  // Simulated user data for demo
  final Map<String, String> _users = {
    'user@example.com': 'password123',
    '9800917189': 'password123',
  };

  Future<bool> loginUser({
    required String identifier, // email or phone
    required String password,
  }) async {
    // Simulate network delay
    await Future.delayed(const Duration(seconds: 1));

    // Check if identifier exists and password matches
    if (_users.containsKey(identifier) && _users[identifier] == password) {
      print('Login success for $identifier');
      return true;
    }

    print('Login failed for $identifier');
    return false;
  }
}
