import 'package:flutter/material.dart';
import 'package:myperioddiary/LandingPage/landing.dart';



const Color babyPink = Color(0xFFFFB6C1);

class YogaPosesApp extends StatelessWidget {
  const YogaPosesApp({Key? key}) : super(key: key);

  // Move babyPink color to top-level constant for accessibility in TableRow decoration
  static const Color babyPink = Color(0xFFFFB6C1);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Yoga Poses Table',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: babyPink,
        fontFamily: 'Segoe UI',
        appBarTheme: const AppBarTheme(
          backgroundColor: babyPink,
          elevation: 0,
          foregroundColor: Colors.white,
        ),
      ),
      home: const YogaPosesPage(),
      routes: {
        '/landing': (context) =>  const RootPage(),
      },
    );
  }
}

class YogaPosesPage extends StatefulWidget {
  const YogaPosesPage({Key? key}) : super(key: key);

  @override
  State<YogaPosesPage> createState() => _YogaPosesPageState();
}

class _YogaPosesPageState extends State<YogaPosesPage> {
  static const Color babyPinkLight = Color(0xFFFFD7E0);

  final List<YogaPose> poses = const [
    YogaPose(
      name: "Child’s Pose (Balasana)",
      img: 'assets/images/childpose.png',
      desc: "Relieves cramps, soothes lower back, relaxes pelvic area. Best for cramping and anxiety.",
    ),
    YogaPose(
      name: "Cat-Cow (Marjaryasana-Bitilasana)",
      img: 'assets/images/catcow.png',
      desc: "Gently massages uterus and belly, eases backache, good for mild discomfort.",
    ),
    YogaPose(
      name: "Reclining Twist (Supta Matsyendrasana)",
      img: 'assets/images/reclinedtwist.png',
      desc: "Relieves lower back tension, helps digestion, aids bloating. Best for pain relief.",
    ),
    YogaPose(
      name: "Seated Forward Fold",
      img: 'assets/images/Seated Forward Fold.png',
      desc: "Calms anxiety & mild cramps, stretches spine and hamstrings.",
    ),
    YogaPose(
      name: "Happy Baby Pose (Ananda Balasana)",
      img: 'assets/images/HappyBabyPose.png',
      desc: "Opens hips, relieves pelvic fatigue/pressure. Good for heavy flow days.",
    ),
    YogaPose(
      name: "Supported Bridge Pose",
      img: 'assets/images/SupportedBridgePose.png',
      desc: "Mild inversion with prop; relieves period fatigue and gently tones lower abdomen.",
    ),
    YogaPose(
      name: "Reclining Bound Angle",
      img: 'assets/images/RecliningBoundAngle.png',
      desc: "Reduces period bloating and cramps, calms stress, good for heaviness.",
    ),
    YogaPose(
      name: "Legs up the Wall",
      img: 'assets/images/LegsuptheWall.png',
      desc: "Alleviates leg heaviness, eases fatigue from heavy flow; avoid if flow is very heavy.",
    ),
    YogaPose(
      name: "Sphinx Pose",
      img: 'assets/images/SphinxPose.png',
      desc: "Gentle backbend, relieves tension and mild ache in lower back.",
    ),
    YogaPose(
      name: "Butterfly Pose",
      img: 'assets/images/ButterflyPose.png',
      desc: "Stretches inner thighs, releases pelvic tension. Best for day 2-4 discomfort.",
    ),
    YogaPose(
      name: "Supine Pigeon",
      img: 'assets/images/SupinePigeon.png',
      desc: "Eases sciatic pain and lower back tightness that may flare with hormonal shifts.",
    ),
    YogaPose(
      name: "Supported Fish Pose",
      img: 'assets/images/SupportedFishPose.png',
      desc: "Opens the chest/abdomen, lessens fatigue and mild breast tenderness.",
    ),
    YogaPose(
      name: "Knee-to-Chest",
      img: 'assets/images/Knee-to-Chest.png',
      desc: "Relieves bloating, mild gas pain, and calms menstrual abdominal tension.",
    ),
    YogaPose(
      name: "Savasana",
      img: 'assets/images/Savasana.png',
      desc: "Encourages full relaxation, restores energy, lowers anxiety and mood swings.",
    ),
    YogaPose(
      name: "Thread the Needle",
      img: 'assets/images/ThreadtheNeedlePose.png',
      desc: "Releases tension in shoulders/upper back, helps with aches from posture.",
    ),
  ];

  YogaPose? _selectedPose;

  void _showImageModal(YogaPose pose) {
    setState(() => _selectedPose = pose);
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Scaffold(
            backgroundColor: Colors.black54,
            body: Center(
              child: Stack(
                children: [
                  InteractiveViewer(
                    maxScale: 5,
                    minScale: 1,
                    child: Image.asset(
                      pose.img,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.image_not_supported,
                        size: 100,
                        color: Colors.white54,
                      ),
                    ),
                  ),
                  Positioned(
                    top: 40,
                    right: 20,
                    child: IconButton(
                      icon: const Icon(Icons.close, size: 30, color: Colors.white),
                      onPressed: () => Navigator.of(context).pop(),
                      tooltip: 'Close',
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    ).then((_) => setState(() => _selectedPose = null));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MyPeriodDiary'),
        centerTitle: false,
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/landing');
            },
            child: const Text(
              'Back',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
      backgroundColor: babyPink,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(minWidth: 700),
                  child: SingleChildScrollView(
                    child: Table(
                      border: TableBorder.all(width: 1, color: Colors.grey),
                      columnWidths: const {
                        0: FixedColumnWidth(200),
                        1: FixedColumnWidth(100),
                        2: FixedColumnWidth(300),
                      },
                      children: [
                        TableRow(
                          decoration: const BoxDecoration(color: babyPink),
                          children: const [
                            Padding(
                              padding: EdgeInsets.all(8),
                              child: Text(
                                'Yoga Pose',
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(8),
                              child: Text(
                                'Image',
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.all(8),
                              child: Text(
                                'Description',
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                        ...poses.map((pose) {
                          return TableRow(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8),
                                child: Text(
                                  pose.name,
                                  style: const TextStyle(fontWeight: FontWeight.w600),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8),
                                child: GestureDetector(
                                  onTap: () => _showImageModal(pose),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: Image.asset(
                                      pose.img,
                                      width: 80,
                                      height: 80,
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => Container(
                                        width: 80,
                                        height: 80,
                                        color: Colors.grey[300],
                                        child: const Icon(Icons.broken_image),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8),
                                child: Text(pose.desc),
                              ),
                            ],
                          );
                        }).toList(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// YogaPose data class
class YogaPose {
  final String name;
  final String img;
  final String desc;

  const YogaPose({
    required this.name,
    required this.img,
    required this.desc,
  });
}


