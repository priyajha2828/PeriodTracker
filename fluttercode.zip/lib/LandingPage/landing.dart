import 'package:flutter/material.dart';

import 'package:image_picker/image_picker.dart';
import 'package:myperioddiary/login/ui/login_page.dart';
import 'dart:io';

import 'package:table_calendar/table_calendar.dart';
import '../FoodReceipe/foodreceipe.dart';
import '../medicine/medicine.dart';
import '../suggestion/suggestion.dart';
import '../ProfilePage/profile_page.dart';
import '../yoga/yoga.dart';


const Color babyPink = Color(0xFFFFB6C1);

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyPeriodDiary',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: babyPink,
        scaffoldBackgroundColor: babyPink,
        appBarTheme: const AppBarTheme(
          backgroundColor: babyPink,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
      ),
      home: const RootPage(),
      routes: {
        '/recipe': (context) => FoodRecipesScreen(),
        '/yoga': (context) =>  const YogaPosesApp(),
        '/_daySuggestions': (context) => const PeriodSuggestionsPage(),
        '/medicine': (context) => const MyPeriodDiaryMedicinesApp(),
        '/login': (context) => const LoginScreen(),
        // '/suggestion' removed as per your previous requirement
      },
    );
  }
}

class RootPage extends StatefulWidget {
  const RootPage({Key? key}) : super(key: key);

  @override
  State<RootPage> createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  List<PeriodCycle> cycleHistory = [];
  DateTime? currentPeriodStart;
  int currentPeriodLength = 5;
  int currentCycleLength = 28;
  late final List<Widget> _tabs; // only declared once here
  int _selectedIndex = 0;

  final List<_NotificationItem> notifications = [
    _NotificationItem('Period Reminder', 'Your period starts in 3 days.'),
    _NotificationItem('Symptom Alert', 'Remember to track your symptoms today!'),
    _NotificationItem('Health Tip', 'Stay hydrated and well-rested'),
  ];

  @override
  void initState() {
    super.initState();

    _tabs = [
      const HomePage(),
      const CalendarPage(),
      MyPeriodDiaryProfileApp()
      // ProfilePage(
      //   cycleHistory: cycleHistory,
      //   currentPeriodStart: currentPeriodStart,
      //   currentPeriodLength: currentPeriodLength,
      //   currentCycleLength: currentCycleLength,
      // ),
    ];
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _showNotifications(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (BuildContext context) {
        if (notifications.isEmpty) {
          return SizedBox(
            height: 200,
            child: Center(
              child: Text(
                'No new notifications',
                style: TextStyle(
                    color: babyPink, fontSize: 18, fontWeight: FontWeight.w600),
              ),
            ),
          );
        }
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Notifications',
                  style: TextStyle(
                    color: babyPink,
                    fontWeight: FontWeight.bold,
                    fontSize: 22,
                  ),
                ),
                const SizedBox(height: 16),
                Flexible(
                  child: ListView.separated(
                    shrinkWrap: true,
                    itemCount: notifications.length,
                    separatorBuilder: (_, __) => const Divider(),
                    itemBuilder: (context, index) {
                      final item = notifications[index];
                      return ListTile(
                        leading: const Icon(Icons.notifications, color: Colors.redAccent),
                        title: Text(item.title,
                            style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black87)),
                        subtitle: Text(item.message),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        );
      },
    );
  }

  String _getAppBarTitle(int index) {
    switch (index) {
      case 0:
        return 'Home';
      case 1:
        return 'Calendar';
    // case 2: suggestions tab removed
      case 2:
        return 'Profile';
      default:
        return '';
    }
  }

  void _logout() {
    // Perform logout logic here: clear session, tokens, etc.
    // Navigate to login page replacing current route stack
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_getAppBarTitle(_selectedIndex)),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none),
            tooltip: "Notifications",
            onPressed: () => _showNotifications(context),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: "Logout",
            onPressed: () {
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context){
                return LoginScreen();
              }));
            },
          ),
        ],
      ),
      body: SafeArea(
        child: _tabs[_selectedIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: babyPink,
        unselectedItemColor: Colors.grey[600],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        backgroundColor: Colors.white,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_filled),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today_rounded),
            label: 'Calendar',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

// === Home Page Section ===
class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Text(
        title,
        style: const TextStyle(
            color: Colors.white, fontSize: 22, fontWeight: FontWeight.w600),
      ),
    );
  }

  Widget _buildCard({
    required IconData icon,
    required String title,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.all(8),
          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.25),
                offset: const Offset(0, 4),
                blurRadius: 10,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 40, color: color),
              const SizedBox(height: 12),
              Text(
                title,
                style: TextStyle(
                    fontWeight: FontWeight.w600, color: color, fontSize: 18),
                textAlign: TextAlign.center,
              )
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Ensure babyPink background on the whole Home page.
    return Container(
      color: babyPink,
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile section
            Row(
              children: const [
                CircleAvatar(
                  radius: 32,
                  backgroundImage: AssetImage(''),
                  backgroundColor: Colors.white,
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Text(
                    'Hello Priya',
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 22,
                        color: Colors.white
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            _buildSectionTitle('Suggestions'),
            Row(
              children: [
                _buildCard(
                  icon: Icons.lightbulb_outline,
                  title: 'Suggestions',
                  color: babyPink,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>  const PeriodSuggestionsPage()),
                    );
                    // No suggestions screen currently, do nothing or route elsewhere
                  },
                ),
                _buildCard(
                  icon: Icons.restaurant_menu,
                  title: 'Food Recipe',
                  color: Colors.orangeAccent,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => FoodRecipesScreen()),
                    );
                  },

                ),
              ],
            ),
            _buildSectionTitle('Yoga & Medicine'),
            Row(
              children: [
                _buildCard(
                  icon: Icons.self_improvement,
                  title: 'Yoga',
                  color: Colors.greenAccent,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => YogaPosesApp()),
                    );
                  },
                ),
                _buildCard(
                  icon: Icons.medical_services,
                  title: 'Medicine',
                  color: Colors.purpleAccent,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyPeriodDiaryMedicinesApp()),
                    );
                  },
                ),
              ],
            )

          ],
        ),
      ),
    );
  }
}

// === Calendar Page (with TableCalendar) ===

class CalendarPage extends StatefulWidget {
  const CalendarPage({Key? key}) : super(key: key);

  @override
  State<CalendarPage> createState() => _CalendarPageState();
}

enum CyclePhase { Menstrual, Follicular, Ovulation, Luteal }

class _CalendarPageState extends State<CalendarPage> {
  DateTime today = DateTime.now();
  DateTime? periodStart;
  int periodLength = 5;
  int cycleLength = 28; // Typical cycle length

  // Removed notifications and profile related properties & methods

  // Calculate phase for given date based on periodStart
  CyclePhase? _getPhaseForDay(DateTime date) {
    if (periodStart == null) return null;

    int dayNum = date.difference(periodStart!).inDays + 1;
    if (dayNum < 1 || dayNum > cycleLength) return null;

    if (dayNum <= periodLength) {
      return CyclePhase.Menstrual;
    } else if (dayNum > periodLength && dayNum < 14) {
      return CyclePhase.Follicular;
    } else if (dayNum == 14) {
      return CyclePhase.Ovulation;
    } else if (dayNum > 14 && dayNum <= cycleLength) {
      return CyclePhase.Luteal;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    // Wrap the content in SingleChildScrollView to fix bottom overflow issues
    return Scaffold(
      backgroundColor: babyPink,
      appBar: AppBar(
        title: const Text("Period Calendar"),
        backgroundColor: babyPink,
        foregroundColor: Colors.white,
        elevation: 0,
        // Removed profile and notification actions from AppBar
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 16), // reduced bottom padding to avoid overflow by 56 px
        child: Column(
          children: [
            TableCalendar(
              firstDay: DateTime.utc(today.year, today.month - 3, 1),
              lastDay: DateTime.utc(today.year, today.month + 4, 31),
              focusedDay: periodStart ?? today,
              calendarStyle: CalendarStyle(
                todayDecoration: BoxDecoration(
                  color: Colors.white70,
                  shape: BoxShape.circle,
                ),
                selectedDecoration: BoxDecoration(
                  color: Colors.redAccent,
                  shape: BoxShape.circle,
                ),
                markerDecoration: const BoxDecoration(
                  color: Colors.pink,
                  shape: BoxShape.circle,
                ),
                weekendTextStyle: const TextStyle(color: Colors.pinkAccent),
                outsideDaysVisible: false,
              ),
              headerStyle: const HeaderStyle(
                formatButtonVisible: false,
                titleCentered: true,
                titleTextStyle: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 22,
                ),
                leftChevronIcon: Icon(Icons.chevron_left, color: Colors.white),
                rightChevronIcon: Icon(Icons.chevron_right, color: Colors.white),
              ),
              selectedDayPredicate: (day) =>
              periodStart != null &&
                  day.isAfter(periodStart!.subtract(const Duration(days: 1))) &&
                  day.isBefore(periodStart!.add(Duration(days: periodLength))),
              calendarBuilders: CalendarBuilders(
                defaultBuilder: (context, date, _) {
                  CyclePhase? phase = _getPhaseForDay(date);
                  if (phase != null) {
                    Color bgColor;
                    String label;
                    switch (phase) {
                      case CyclePhase.Menstrual:
                        bgColor = Colors.redAccent;
                        label = "M";
                        break;
                      case CyclePhase.Follicular:
                        bgColor = Colors.orangeAccent;
                        label = "F";
                        break;
                      case CyclePhase.Ovulation:
                        bgColor = Colors.greenAccent;
                        label = "O";
                        break;
                      case CyclePhase.Luteal:
                        bgColor = Colors.purpleAccent;
                        label = "L";
                        break;
                    }
                    return Tooltip(
                      message: _phaseName(phase),
                      child: CircleAvatar(
                        backgroundColor: bgColor,
                        child: Text(label,
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 14)),
                      ),
                    );
                  }
                  return null;
                },
              ),
              onDaySelected: (selectedDay, _) {
                setState(() {
                  today = selectedDay;
                });
                if (periodStart != null) {
                  int dayIndex = selectedDay.difference(periodStart!).inDays + 1;
                  if (dayIndex > 0 && dayIndex <= periodLength) {
                    _showSuggestions(context, dayIndex);
                  }
                }
              },
              onFormatChanged: (_) {},
              onPageChanged: (_) {},
              availableGestures: AvailableGestures.all,
            ),
            const SizedBox(height: 24),
            periodStart == null
                ? ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: babyPink,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
              onPressed: () async {
                DateTime? picked = await showDatePicker(
                  context: context,
                  initialDate: today,
                  firstDate: DateTime(today.year - 1),
                  lastDate: DateTime(today.year + 1),
                );
                if (picked != null) setState(() {
                  periodStart = picked;
                });
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                child: Text("Select Period Start Date",
                    style: TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 18)),
              ),
            )
                : _periodIndicator(context),
          ],
        ),
      ),
    );
  }

  String _phaseName(CyclePhase phase) {
    switch (phase) {
      case CyclePhase.Menstrual:
        return "Menstrual Phase";
      case CyclePhase.Follicular:
        return "Follicular Phase";
      case CyclePhase.Ovulation:
        return "Ovulation Day";
      case CyclePhase.Luteal:
        return "Luteal Phase";
      default:
        return "";
    }
  }

  Widget _periodIndicator(BuildContext context) {
    return Column(
      children: [
        Text(
          "Period Start: ${_dateText(periodStart!)}\nPeriod Length: $periodLength days",
          textAlign: TextAlign.center,
          style: const TextStyle(
              color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 8),
        Text(
          "Tap any highlighted date to view food, yoga, meds & tips!",
          style: TextStyle(
              color: Colors.pink[50], fontSize: 15, fontStyle: FontStyle.italic),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 20),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
              backgroundColor: Colors.pink[100],
              foregroundColor: Colors.pink,
              shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
          onPressed: () {
            setState(() {
              periodStart = null;
            });
          },
          child: const Padding(
            padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
            child: Text("Reset Period Date"),
          ),
        )
      ],
    );
  }

  String _dateText(DateTime d) =>
      "${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}";

  void _showSuggestions(BuildContext context, int dayOfPeriod) {
    final dayData = _periodDaySuggestions(dayOfPeriod);

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      isScrollControlled: true,
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        minChildSize: 0.5,
        initialChildSize: 0.75,
        builder: (context, scrollController) => SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text("Day $dayOfPeriod Suggestions",
                  style: const TextStyle(
                      color: babyPink, fontSize: 21, fontWeight: FontWeight.bold)),
              const SizedBox(height: 14),
              _suggestionTile("Food", dayData["food"]!),
              _suggestionTile("Yoga", dayData["yoga"]!),
              _suggestionTile("Medicine/Tips", dayData["meds"]!),
              const SizedBox(height: 18),
              Text("Daily Period Q&A",
                  style: TextStyle(
                      color: Colors.pink[400], fontSize: 19, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              _PeriodQuestionnaire(day: dayOfPeriod),
            ],
          ),
        ),
      ),
    );
  }

  Widget _suggestionTile(String title, String body) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Container(
        decoration: BoxDecoration(
          color: babyPink.withAlpha(30),
          borderRadius: BorderRadius.circular(14),
        ),
        child: ListTile(
          title: Text(title,
              style: const TextStyle(
                  color: babyPink, fontWeight: FontWeight.bold, fontSize: 16)),
          subtitle: Text(
            body,
            style: const TextStyle(
                color: Colors.black87, fontWeight: FontWeight.w600, fontSize: 15),
          ),
        ),
      ),
    );
  }

  Map<String, String> _periodDaySuggestions(int day) {
    if (day == 1) {
      return {
        "food":
        "Eat iron-rich warm foods (spinach, lentils), hydrate, avoid very cold drinks.",
        "yoga":
        "Gentle poses: Child’s Pose, Cat-Cow, Reclining Twist. Avoid inversions.",
        "meds":
        "If severe cramps: Ibuprofen (as advised). Meftal. Avoid NSAIDs if contraindicated.",
      };
    } else if (day == 2) {
      return {
        "food": "Continue iron-rich meals, add bananas & yogurt for cramps & energy.",
        "yoga": "Light flow or restorative yoga, focus on breathing and stretching.",
        "meds": "Continue pain relief if needed. Use hot water bottle for extra comfort.",
      };
    } else if (day == 3) {
      return {
        "food": "Add vitamin B6 foods (chickpeas, oatmeal), keep hydrating.",
        "yoga": "Seated Forward Fold, Happy Baby Pose.",
        "meds": "Reduce meds if cramps are subsiding, prefer natural pain relief.",
      };
    } else {
      return {
        "food": "Normal balanced diet, but hydrate and rest. Light iron intake.",
        "yoga": "Mild stretching, gentle walk or yoga if energy permits.",
        "meds": "Minimal, if any. Observe if pain recurs.",
      };
    }
  }
}

class _PeriodQuestionnaire extends StatefulWidget {
  final int day;

  const _PeriodQuestionnaire({Key? key, required this.day}) : super(key: key);

  @override
  State<_PeriodQuestionnaire> createState() => _PeriodQuestionnaireState();
}

class _PeriodQuestionnaireState extends State<_PeriodQuestionnaire> {
  final _formKey = GlobalKey<FormState>();
  String mood = "";
  String flow = "";
  String pain = "";
  String discharge = "";
  String energy = "";

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          _qTile("Mood over the day?", "e.g., Anxious, irritable, depressed, tired, normal",
                  (v) => mood = v),
          _qTile("How heavy/light was your blood flow?",
              "e.g., Heavy, light, similar to usual, changed?", (v) => flow = v),
          _qTile("Did you experience any pain? Where/intensity?",
              "e.g., Cramps, back, breasts, head, mild/moderate/severe", (v) => pain = v),
          _qTile("Any changes in vaginal discharge or odor?",
              "e.g., Clear, white, thick, smelly, discolored, normal", (v) => discharge = v),
          _qTile("How were your energy/digestion?",
              "e.g., Energized, fatigued, constipation, bloating, normal", (v) => energy = v),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                // Normally save answers to user data/storage here
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Responses saved!")),
                );
                Navigator.pop(context);
              }
            },
            child: const Text("Submit"),
            style: ElevatedButton.styleFrom(
                backgroundColor: babyPink, foregroundColor: Colors.white),
          )
        ],
      ),
    );
  }

  Widget _qTile(String question, String hint, Function(String) onSaved) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextFormField(
        decoration: InputDecoration(
          labelText: question,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          labelStyle: const TextStyle(color: babyPink, fontWeight: FontWeight.bold),
        ),
        validator: (v) => v == null || v.isEmpty ? "Please provide an answer." : null,
        onChanged: onSaved,
      ),
    );
  }
}

// User profile page with editable username, image, cycle history and notes
class ProfilePage extends StatefulWidget {
  final List<PeriodCycle> cycleHistory;
  final DateTime? currentPeriodStart;
  final int currentPeriodLength;
  final int currentCycleLength;

  const ProfilePage({
    Key? key,
    required this.cycleHistory,
    required this.currentPeriodStart,
    required this.currentPeriodLength,
    required this.currentCycleLength,
  }) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late TextEditingController usernameController;
  File? _userImage;

  @override
  void initState() {
    super.initState();
    usernameController = TextEditingController(text: "User");
  }

  @override
  void dispose() {
    usernameController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? pickedImage =
    await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (pickedImage != null) {
      setState(() {
        _userImage = File(pickedImage.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("User Profile"),
        backgroundColor: babyPink,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: _pickImage,
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.white,
                backgroundImage:
                _userImage != null ? FileImage(_userImage!) : null,
                child: _userImage == null
                    ? const Icon(Icons.person, size: 50, color: babyPink)
                    : null,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: usernameController,
              decoration: InputDecoration(
                labelText: "Username",
                border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 24),

            const Text("Period Cycle History",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: babyPink)),

            const SizedBox(height: 12),
            ...List.generate(widget.cycleHistory.length, (index) {
              final cycle = widget.cycleHistory[index];
              return Card(
                elevation: 2,
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  title:
                  Text("Cycle ${index + 1}: ${_formatDate(cycle.startDate)} to ${_formatDate(cycle.endDate)}"),
                  subtitle: Text("Flow: ${cycle.flowIntensity}\nNotes: ${cycle.notes ?? '-'}"),
                  onTap: () {
                    // Could navigate to detailed history or edit answers here
                  },
                ),
              );
            }),

            const SizedBox(height: 24),

            const Text("Suggestions & Health Info (example)",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: babyPink)),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                title: const Text("Food Suggestions"),
                subtitle:
                Text("Spinach, lentils, bananas, yogurt, ginger tea, etc."),
              ),
            ),
            Card(
              child: ListTile(
                title: const Text("Yoga Recommendations"),
                subtitle: Text(
                    "Child’s Pose, Reclining Twist, Cat-Cow, Seated Forward Fold."),
              ),
            ),
            Card(
              child: ListTile(
                title: const Text("Medicines & Tips"),
                subtitle: Text(
                    "Use heat packs for cramps, Ibuprofen if necessary, consult doctor if severe."),
              ),
            ),

            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                // You could add save logic here (e.g., save username, profile image & cycle history)
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Profile saved!")));
              },
              child: const Text("Save Profile"),
              style: ElevatedButton.styleFrom(
                  backgroundColor: babyPink, foregroundColor: Colors.white),
            )
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime d) =>
      "${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}";
}

// Simple period cycle data class to keep history & answers
class PeriodCycle {
  final DateTime startDate;
  final DateTime endDate;
  String flowIntensity; // e.g., Light, Normal, Heavy
  Map<String, dynamic> answers;
  String? notes;

  PeriodCycle({
    required this.startDate,
    required this.endDate,
    required this.flowIntensity,
    required this.answers,
    this.notes,
  });
}

class _NotificationItem {
  final String title;
  final String message;

  _NotificationItem(this.title, this.message);
}



class YogaPage extends StatelessWidget {
  const YogaPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return _placeholderPage('Yoga');
  }
}


class MedicinePage extends StatelessWidget {
  const MedicinePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return _placeholderPage('Medicine');
  }
}

Widget _placeholderPage(String title) {
  return Scaffold(
    appBar: AppBar(
      title: Text(title),
      backgroundColor: babyPink,
      foregroundColor: Colors.white,
    ),
    body: Center(
      child: Text(
        '$title Page Coming Soon!',
        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
      ),
    ),
    backgroundColor: babyPink,
  );
}




