import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:myperioddiary/LandingPage/landing.dart';
// Import your actual landing page here if you have it instead of the placeholder below
// import '../LandingPage/landing.dart';

void main() {
  runApp(const MyPeriodDiaryMedicinesApp());
}

class MyPeriodDiaryMedicinesApp extends StatelessWidget {
  const MyPeriodDiaryMedicinesApp({Key? key}) : super(key: key);

  static const Color babyPink = Color(0xFFFFB6C1);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyPeriodDiary - Medicines',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: babyPink,
        primaryColor: babyPink,
        fontFamily: 'Arial',
        textTheme: const TextTheme(
          bodyMedium: TextStyle(color: Color(0xFF44213C), fontSize: 16),
        ),
      ),
      home: const MedicinePage(),
      routes: {
        '/landingpage': (context) => const  RootPage(), // Add your real LandingPage here
      },
    );
  }
}

// Medicine data model
class Medicine {
  final String medicineName;
  final String dosage;
  final String frequency;
  final String symptoms;
  final String sideEffect;
  final DateTime timestamp;

  Medicine({
    required this.medicineName,
    required this.dosage,
    required this.frequency,
    required this.symptoms,
    required this.sideEffect,
    required this.timestamp,
  });
}

class MedicinePage extends StatelessWidget {
  const MedicinePage({Key? key}) : super(key: key);

  static const Color babyPink = MyPeriodDiaryMedicinesApp.babyPink;

  static final List<Medicine> medicines = [
    Medicine(
      medicineName: 'Ibuprofen (Advil, Motrin IB)',
      dosage: '200–400 mg (OTC) or up to 800 mg',
      frequency: 'Every 6–8 hours as needed, for 2–3 days',
      symptoms: 'Menstrual cramps, lower abdominal pain, headache, heavy bleeding',
      sideEffect: 'Upset stomach, nausea, heartburn, dizziness, kidney issues',
      timestamp: DateTime.parse('2025-08-03 01:12:00'),
    ),
    Medicine(
      medicineName: 'Naproxen (Aleve)',
      dosage: '250–500 mg',
      frequency: 'Every 8–12 hours, for 2–3 days',
      symptoms: 'Menstrual cramps, heavy bleeding',
      sideEffect: 'Stomach upset, heartburn, headache, drowsiness',
      timestamp: DateTime.parse('2025-08-03 01:12:00'),
    ),
    Medicine(
      medicineName: 'Tranexamic Acid (Lysteda)',
      dosage: '650–1,300 mg',
      frequency: 'Three times daily, up to 5 days',
      symptoms: 'Heavy menstrual bleeding',
      sideEffect: 'Nausea, diarrhea, headache, muscle cramps',
      timestamp: DateTime.parse('2025-08-03 01:12:00'),
    ),
    Medicine(
      medicineName: 'Mefenamic Acid (Ponstel)',
      dosage: '500 mg first dose, then 250 mg',
      frequency: 'Every 6 hours as needed, for 2–3 days',
      symptoms: 'Menstrual cramps, heavy bleeding',
      sideEffect: 'Nausea, diarrhea, stomach pain, dizziness',
      timestamp: DateTime.parse('2025-08-03 01:12:00'),
    ),
    Medicine(
      medicineName: 'Combined Oral Contraceptive Pills',
      dosage: 'Varies (e.g., 0.035 mg ethinyl estradiol/0.25 mg norgestimate)',
      frequency: 'One pill daily, start day 1 or as directed',
      symptoms: 'Irregular periods, heavy bleeding, painful periods, PMS',
      sideEffect: 'Nausea, breast tenderness, breakthrough bleeding, mood changes',
      timestamp: DateTime.parse('2025-08-03 01:12:00'),
    ),
    Medicine(
      medicineName: 'Norethisterone (Primolut N)',
      dosage: '5 mg',
      frequency: 'Three times daily, start 3 days before period or day 1',
      symptoms: 'Heavy/irregular periods, period delay',
      sideEffect: 'Breakthrough bleeding, breast tenderness, nausea, headache',
      timestamp: DateTime.parse('2025-08-03 01:12:00'),
    ),
    Medicine(
      medicineName: 'Medroxyprogesterone Acetate (Provera)',
      dosage: '2.5–10 mg',
      frequency: 'Once daily for 5–10 days, start day 1 or as directed',
      symptoms: 'Irregular periods, heavy bleeding, endometriosis',
      sideEffect: 'Bloating, mood swings, breast tenderness, irregular bleeding',
      timestamp: DateTime.parse('2025-08-03 01:12:00'),
    ),
  ];

  String formatTimestamp(DateTime dateTime) {
    return DateFormat('dd/MM/yyyy hh:mm a').format(dateTime);
  }

  @override
  Widget build(BuildContext context) {
    // Responsive padding for narrow devices
    final horizontalPadding =
    MediaQuery.of(context).size.width < 700 ? 8.0 : 16.0;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              color: babyPink,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const SizedBox(width: 1), // to align right button
                  const Text(
                    'MyPeriodDiary',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                      fontFamily: 'Arial',
                    ),
                  ),

                  // Back button which replaces current page with LandingPage
                  TextButton.icon(
                    onPressed: () {
                      Navigator.pushReplacementNamed(context, '/landingpage');
                    },
                    icon: const Icon(
                      Icons.arrow_forward,
                      color: Colors.white,
                      size: 20,
                    ),
                    label: const Text(
                      'Back',
                      style:
                      TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                    ),
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.white,
                    ),
                  )
                ],
              ),
            ),

            // Content
            Expanded(
              child: Center(
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 530),
                  margin:
                  EdgeInsets.symmetric(horizontal: horizontalPadding, vertical: 20),
                  padding: const EdgeInsets.symmetric(
                      vertical: 20, horizontal: 18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xFFF6CADF44), // semi-transparent pink shadow
                        blurRadius: 12,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'Medicines',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: babyPink,
                          fontWeight: FontWeight.w800,
                          fontSize: 20,
                          fontFamily: 'Arial',
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 16),

                      Expanded(
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: DataTable(
                            headingRowColor: MaterialStateProperty.all(
                                const Color(0xFFFFE3EA)),
                            headingTextStyle: const TextStyle(
                              color: Color(0xFFB63A7A),
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                              fontFamily: 'Arial',
                            ),
                            dataTextStyle: const TextStyle(
                              color: Color(0xFF3F1440),
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Arial',
                            ),
                            columns: const [
                              DataColumn(label: Text('Name')),
                              DataColumn(label: Text('Dosage')),
                              DataColumn(label: Text('Frequency')),
                              DataColumn(label: Text('Symptoms')),
                              DataColumn(label: Text('Side Effects')),
                              DataColumn(label: Text('Timestamp')),
                            ],
                            rows: medicines.isEmpty
                                ? []
                                : medicines.map((m) {
                              return DataRow(cells: [
                                DataCell(Text(m.medicineName)),
                                DataCell(Text(m.dosage)),
                                DataCell(Text(m.frequency)),
                                DataCell(Text(m.symptoms)),
                                DataCell(Text(m.sideEffect)),
                                DataCell(Text(formatTimestamp(m.timestamp))),
                              ]);
                            }).toList(),
                          ),
                        ),
                      ),

                      if (medicines.isEmpty)
                        const Padding(
                          padding: EdgeInsets.all(16),
                          child: Center(
                            child: Text(
                              'No medicines available.',
                              style: TextStyle(
                                color: Color(0xFF9B7F91),
                                fontStyle: FontStyle.italic,
                                fontFamily: 'Arial',
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


