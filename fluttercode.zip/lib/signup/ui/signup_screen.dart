import 'package:flutter/material.dart';

import '../../login/ui/login_page.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late AutovalidateMode autoValidateMode;

  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController middleNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController dobController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    autoValidateMode = AutovalidateMode.disabled;
  }

  @override
  void dispose() {
    firstNameController.dispose();
    middleNameController.dispose();
    lastNameController.dispose();
    dobController.dispose();
    emailController.dispose();
    phoneController.dispose();
    addressController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sign Up"),
      ),
      body: Form(
        key: _formKey,
        autovalidateMode: autoValidateMode,
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 12.0),
          children: [
            Image.asset("assets/images/2.jpg", height: 200.0),
            const SizedBox(height: 30),

            TextFormField(
              controller: firstNameController,
              decoration: _inputDecoration("First Name", Icons.person),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return "First name is required";
                }
                return null;
              },
            ),
            const SizedBox(height: 10),

            TextFormField(
              controller: middleNameController,
              decoration: _inputDecoration("Middle Name (Optional)", Icons.person_outline),
            ),
            const SizedBox(height: 10),

            TextFormField(
              controller: lastNameController,
              decoration: _inputDecoration("Last Name", Icons.person),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return "Last name is required";
                }
                return null;
              },
            ),
            const SizedBox(height: 10),

            TextFormField(
              controller: dobController,
              readOnly: true,
              decoration: _inputDecoration("Date of Birth", Icons.calendar_today),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return "Date of birth is required";
                }
                return null;
              },
              onTap: () async {
                FocusScope.of(context).requestFocus(FocusNode()); // Hide keyboard
                DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: DateTime(2000),
                  firstDate: DateTime(1900),
                  lastDate: DateTime.now(),
                );
                if (pickedDate != null) {
                  dobController.text = "${pickedDate.year}-${pickedDate.month.toString().padLeft(2, '0')}-${pickedDate.day.toString().padLeft(2, '0')}";
                }
              },
            ),
            const SizedBox(height: 10),

            TextFormField(
              controller: emailController,
              keyboardType: TextInputType.emailAddress,
              decoration: _inputDecoration("Email", Icons.email_outlined),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return "Email is required";
                }
                const pattern = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';
                final regex = RegExp(pattern);
                if (!regex.hasMatch(val.trim())) {
                  return "Enter a valid email";
                }
                return null;
              },
            ),
            const SizedBox(height: 10),

            TextFormField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              decoration: _inputDecoration("Phone Number", Icons.phone),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return "Phone number is required";
                }
                if (val.trim().length < 7) {
                  return "Enter a valid phone number";
                }
                return null;
              },
            ),
            const SizedBox(height: 10),

            TextFormField(
              controller: addressController,
              decoration: _inputDecoration("Address", Icons.location_on_outlined),
              validator: (val) {
                if (val == null || val.trim().isEmpty) {
                  return "Address is required";
                }
                return null;
              },
            ),
            const SizedBox(height: 10),

            TextFormField(
              controller: passwordController,
              obscureText: true,
              decoration: _inputDecoration("Password", Icons.lock_outline),
              validator: (val) {
                if (val == null || val.isEmpty) {
                  return "Password is required";
                } else if (val.length < 6) {
                  return "Password must be at least 6 characters";
                }
                return null;
              },
            ),

            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: validateInputs,
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
              ),
              child: const Text("Sign Up"),
            ),

            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text("Already have account?"),
                TextButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                          return const LoginScreen();
                        }));
                  },
                  child: const Text("Login"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: const BorderSide(color: Colors.black)),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: const BorderSide(color: Colors.black)),
      errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
          borderSide: const BorderSide(color: Colors.red)),
      suffixIcon: Icon(icon),
    );
  }

  void validateInputs() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      final firstName = firstNameController.text.trim();
      final middleName = middleNameController.text.trim();
      final lastName = lastNameController.text.trim();
      final dob = dobController.text.trim();
      final email = emailController.text.trim();
      final phone = phoneController.text.trim();
      final address = addressController.text.trim();
      final password = passwordController.text;

      // TODO: Add your signup logic here (e.g., API call)

      debugPrint('Signup Data: $firstName $middleName $lastName, DOB: $dob, $email, $phone, $address');

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    } else {
      setState(() {
        autoValidateMode = AutovalidateMode.onUserInteraction;
      });
    }
  }
}
