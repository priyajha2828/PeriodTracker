import 'package:flutter/material.dart';
import '../LandingPage/landing.dart';
void main() => runApp(MyPeriodDiaryApp());

class MyPeriodDiaryApp extends StatelessWidget {
  static const babyPink = Color(0xFFFFB6C1);
  static const babyPinkLight = Color(0xFFFFD7E0);
  static const textMain = Color(0xFF502E32);
  static const white = Colors.white;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyPeriodDiary - Period Suggestions',
      theme: ThemeData(
        primaryColor: babyPink,
        scaffoldBackgroundColor: babyPink,
        fontFamily: 'Segoe UI',
        textTheme: const TextTheme(
          bodyMedium: TextStyle(color: textMain),
          titleLarge: TextStyle(color: white, fontWeight: FontWeight.bold),

        ),
      ),
      home: const PeriodSuggestionsPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class PeriodSuggestionsPage extends StatefulWidget {
  const PeriodSuggestionsPage({Key? key}) : super(key: key);

  @override
  State<PeriodSuggestionsPage> createState() => _PeriodSuggestionsPageState();
}

class _PeriodSuggestionsPageState extends State<PeriodSuggestionsPage> {
  final ScrollController _scrollController = ScrollController();

  final List<DaySuggestion> _daySuggestions = [
    DaySuggestion(
      day: 1,
      title: 'Day 1: First Day of Period (Menstrual Flow Begins)',
      nutrition: [
        'Focus on iron-rich foods to replenish lost iron: spinach, kale, red meat, lentils, tofu, pumpkin seeds.',
        'Include vitamin C-rich foods (like oranges or bell peppers) to help iron absorption.',
        'Stay well hydrated with warm fluids like ginger or chamomile tea.',
      ],
      selfcare: [
        'Use a heating pad on the lower abdomen to relieve cramps.',
        'Practice gentle breathing or mindfulness to manage discomfort.',
      ],
      exercise: [
        'Gentle yoga poses like Child’s Pose, Cat-Cow stretch, or Reclining Twist. Avoid strenuous activities.',
      ],
      medtips: [
        'Use over-the-counter pain relievers like Ibuprofen or Naproxen as prescribed.',
        'Avoid caffeine and alcohol as they can worsen cramps.',
      ],
    ),
    DaySuggestion(
      day: 2,
      title: 'Day 2: Peak Menstrual Flow',
      nutrition: [
        'Continue iron-rich and nutrient-dense foods.',
        'Add magnesium-rich foods (nuts, whole grains, leafy greens).',
        'Snack on bananas for potassium to balance electrolytes and reduce bloating.',
      ],
      selfcare: [
        'Maintain good hygiene; change pads/tampons regularly.',
        'Continue using warm compresses as needed.',
      ],
      exercise: [
        'Engage in restorative yoga or mild stretching to ease muscle tension.',
      ],
      medtips: [
        'Stay hydrated; warm water helps ease cramping.',
        'Avoid cold foods or drinks that may increase uterine contractions.',
      ],
    ),
    DaySuggestion(
      day: 3,
      title: 'Day 3: Mid Menstrual Phase',
      nutrition: [
        'Add vitamin B6-rich foods (chickpeas, oats, poultry) for mood support.',
        'Include probiotics (yogurt, kefir) for gut health.',
        'Keep hydrated with water or herbal teas.',
      ],
      selfcare: [
        'Use aromatherapy with calming scents like lavender or peppermint.',
        'Apply gentle massage on lower back and abdomen for pain relief.',
      ],
      exercise: [
        'Try moderate yoga: Seated Forward Fold, Happy Baby Pose.',
      ],
      medtips: [
        'If cramps ease, reduce pain medications.',
        'Try natural teas like peppermint or raspberry leaf for more support.',
      ],
    ),
    DaySuggestion(
      day: 4,
      title: 'Day 4: Light Flow/End of Menstrual Phase',
      nutrition: [
        'Balance your diet with fiber (whole grains, fruits) to prevent constipation.',
        'Add antioxidant foods (berries, green tea) for cellular repair.',
      ],
      selfcare: [
        'Keep warm and rest as needed.',
        'Do light walks or gentle movement if comfortable.',
      ],
      exercise: [
        'Begin gentle cardio (walking or swimming) if energy returns.',
      ],
      medtips: [
        'If discomfort subsides, medication may not be needed.',
        'Monitor your energy and mood as your cycle transitions.',
      ],
    ),
    DaySuggestion(
      day: 5,
      title: 'Day 5: Spotting/Transition Phase',
      nutrition: [
        'Maintain hydration and continue nutrient-rich meals.',
        'Add healthy omega-3s (flaxseed, walnuts, fatty fish) to reduce inflammation.',
      ],
      selfcare: [
        'Focus on mental health; plan and reflect for the next cycle phase.',
        'Consider journaling symptoms or mood changes.',
      ],
      exercise: [
        'Return to moderate movement (yoga, walk); get ready for more activity in the follicular phase.',
      ],
      medtips: [
        'Prioritize rest, fluid intake, and menstrual tracking.',
      ],
    ),
  ];

  @override
  void initState() {
    super.initState();
    // Scroll to today's date if day 1-5
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final today = DateTime.now().day;
      if (today >= 1 && today <= 5) {
        // Assuming each card height approx 220 + margin => Scroll offset estimated
        // Alternative: Use GlobalKey and Scrollable.ensureVisible for precision
        _scrollController.animateTo(
          (today - 1) * 260.0, // approximate offset per card for smooth scroll
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Widget buildHeader(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      color: MyPeriodDiaryApp.babyPink,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'MyPeriodDiary',
            style: Theme.of(context).textTheme.titleLarge!.copyWith(fontSize: 24),
          ),

          TextButton.icon(
            onPressed: () {
              // Navigate to Landing Page - for demonstration, print or navigate
              Navigator.pushNamed(context, '/landingpage');
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Navigate to Landing Page')),
              );
            },
            icon: const Icon(
              Icons.arrow_forward,
              color: Colors.white,
              size: 20,
            ),
            label: const Text(
              'Back',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
            ),
            style: TextButton.styleFrom(
              foregroundColor: Colors.white,
            ),
          )
        ],
      ),
    );
  }

  Widget buildSuggestionCard(DaySuggestion suggestion) {
    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: MyPeriodDiaryApp.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: const Color.fromRGBO(255, 182, 193, 0.11),
            blurRadius: 24,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            suggestion.title,
            style: TextStyle(
              color: MyPeriodDiaryApp.babyPink,
              fontSize: 20,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          SuggestionSection(title: 'Nutrition', items: suggestion.nutrition),
          SuggestionSection(title: 'Self-Care', items: suggestion.selfcare),
          SuggestionSection(title: 'Exercise', items: suggestion.exercise),
          SuggestionSection(title: 'Medicines & Tips', items: suggestion.medtips),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final maxContentWidth = 640.0;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            buildHeader(context),
            Expanded(
              child: SingleChildScrollView(
                controller: _scrollController,
                padding: const EdgeInsets.symmetric(vertical: 26, horizontal: 12),
                child: Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: maxContentWidth),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        for (final suggestion in _daySuggestions)
                          buildSuggestionCard(suggestion),
                        // If you want to add Resources block, you can add here similar to PHP code
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SuggestionSection extends StatelessWidget {
  final String title;
  final List<String> items;

  const SuggestionSection({
    super.key,
    required this.title,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    final babyPink = MyPeriodDiaryApp.babyPink;
    final textMain = MyPeriodDiaryApp.textMain;

    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: babyPink,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 6),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 4),
            itemBuilder: (_, index) {
              final text = items[index];
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '• ',
                    style: TextStyle(color: textMain, fontSize: 16),
                  ),
                  Expanded(
                    child: Text(
                      text,
                      style: TextStyle(color: textMain, fontSize: 16),
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

/// Model for day suggestions
class DaySuggestion {
  final int day;
  final String title;
  final List<String> nutrition;
  final List<String> selfcare;
  final List<String> exercise;
  final List<String> medtips;

  DaySuggestion({
    required this.day,
    required this.title,
    required this.nutrition,
    required this.selfcare,
    required this.exercise,
    required this.medtips,
  });
}
