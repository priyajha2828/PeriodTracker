import 'package:flutter/material.dart';
import '../../LandingPage/landing.dart'; // Adjust as needed

const Color babyPink = Color(0xFFFFB6C1);

// Enum/Input Data Structures
enum QuestionInputType { date, number, text, choice, multichoice, range, height }

class QuestionPageData {
  final String question;
  final QuestionInputType inputType;
  final String? hint;
  final List<String>? choices;
  final int? rangeMin, rangeMax;
  const QuestionPageData(this.question, {
    required this.inputType,
    this.hint,
    this.choices,
    this.rangeMin,
    this.rangeMax,
  });
}

class DateInputField extends StatefulWidget {
  final String? initialValue;
  final void Function(String formattedDate) onDateSelected;
  const DateInputField({required this.onDateSelected, this.initialValue, super.key});
  @override
  State<DateInputField> createState() => _DateInputFieldState();
}

class _DateInputFieldState extends State<DateInputField> {
  String? selectedDate;
  @override
  void initState() {
    super.initState();
    selectedDate = widget.initialValue;
  }

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () async {
        final now = DateTime.now();
        final picked = await showDatePicker(
          context: context,
          initialDate: now,
          firstDate: DateTime(now.year - 10),
          lastDate: now,
          builder: (context, child) {
            return Theme(
              data: ThemeData.light().copyWith(
                primaryColor: babyPink,
                colorScheme: const ColorScheme.light(primary: babyPink),
              ),
              child: child!,
            );
          },
        );
        if (picked != null) {
          setState(() {
            selectedDate = "${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}";
            widget.onDateSelected(selectedDate!);
          });
        }
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: babyPink,
        minimumSize: const Size(double.infinity, 56),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      child: Text(
        selectedDate ?? "Pick a date",
        style: const TextStyle(color: babyPink, fontWeight: FontWeight.bold, fontSize: 18),
      ),
    );
  }
}

class ChoiceInputField extends StatelessWidget {
  final List<String> choices;
  final String? initialValue;
  final void Function(String) onChoiceSelected;
  const ChoiceInputField({required this.choices, required this.onChoiceSelected, this.initialValue, super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: choices.map((choice) => Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        width: double.infinity,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: initialValue == choice ? babyPink : Colors.white,
            foregroundColor: babyPink,
            elevation: 1,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          onPressed: () => onChoiceSelected(choice),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Text(
              choice,
              style: TextStyle(
                color: initialValue == choice ? Colors.white : babyPink,
                fontWeight: FontWeight.w600,
                fontSize: 17,
              ),
            ),
          ),
        ),
      )).toList(),
    );
  }
}

class MultiChoiceInputField extends StatefulWidget {
  final List<String> choices;
  final List<dynamic> selectedValues;
  final void Function(List<String> selected) onChanged;
  const MultiChoiceInputField({required this.choices, required this.selectedValues, required this.onChanged, super.key});

  @override
  State<MultiChoiceInputField> createState() => _MultiChoiceInputFieldState();
}

class _MultiChoiceInputFieldState extends State<MultiChoiceInputField> {
  late List<String> _selected;
  @override
  void initState() {
    super.initState();
    _selected = List<String>.from(widget.selectedValues);
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: widget.choices.map((choice) => CheckboxListTile(
        title: Text(choice, style: const TextStyle(color: Colors.white, fontSize: 18)),
        activeColor: Colors.white,
        checkColor: babyPink,
        value: _selected.contains(choice),
        onChanged: (val) {
          setState(() {
            if (val == true) {
              _selected.add(choice);
            } else {
              _selected.remove(choice);
            }
            widget.onChanged(_selected);
          });
        },
        controlAffinity: ListTileControlAffinity.leading,
        contentPadding: const EdgeInsets.symmetric(horizontal: 0.0),
      )).toList(),
    );
  }
}

class RangeInputField extends StatelessWidget {
  final int min, max;
  final int value;
  final void Function(int value) onChanged;
  const RangeInputField({required this.min, required this.max, required this.value, required this.onChanged, super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Slider(
          value: value.toDouble(),
          min: min.toDouble(),
          max: max.toDouble(),
          divisions: (max - min),
          activeColor: Colors.white,
          inactiveColor: Colors.white38,
          onChanged: (v) => onChanged(v.round()),
        ),
        Text(
          "$value years",
          style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w600),
        ),
      ],
    );
  }
}

class HeightInputField extends StatelessWidget {
  final int feet;
  final int inches;
  final void Function(int feet, int inches) onChanged;
  const HeightInputField({required this.feet, required this.inches, required this.onChanged, super.key});

  InputDecoration _heightInputDecoration(String label) =>
      InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white),
        enabledBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.white60)),
        focusedBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.white)),
      );

  @override
  Widget build(BuildContext context) {
    const TextStyle dropdownTextStyle = TextStyle(
      color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600,
    );
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Flexible(
          child: Theme(
            data: Theme.of(context).copyWith(
              canvasColor: Colors.white,
            ),
            child: DropdownButtonFormField<int>(
              value: feet,
              decoration: _heightInputDecoration('ft'),
              iconEnabledColor: Colors.white,
              isExpanded: true,
              style: dropdownTextStyle,
              dropdownColor: babyPink,
              items: List.generate(4, (i) => 4 + i)
                  .map((f) => DropdownMenuItem(
                  value: f,
                  child: Text('$f ft',
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 17))))
                  .toList(),
              onChanged: (f) => onChanged(f!, inches),
            ),
          ),
        ),
        const SizedBox(width: 16),
        Flexible(
          child: Theme(
            data: Theme.of(context).copyWith(canvasColor: Colors.white),
            child: DropdownButtonFormField<int>(
              value: inches,
              decoration: _heightInputDecoration('in'),
              iconEnabledColor: Colors.white,
              isExpanded: true,
              style: dropdownTextStyle,
              dropdownColor: babyPink,
              items: List.generate(12, (i) => i)
                  .map((inch) => DropdownMenuItem(
                  value: inch,
                  child: Text('$inch in',
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 17))))
                  .toList(),
              onChanged: (inchesVal) => onChanged(feet, inchesVal!),
            ),
          ),
        ),
      ],
    );
  }
}

class UserQuestionsScreen extends StatefulWidget {
  const UserQuestionsScreen({super.key});

  @override
  State<UserQuestionsScreen> createState() => _UserQuestionsScreenState();
}

class _UserQuestionsScreenState extends State<UserQuestionsScreen> {
  final Map<int, dynamic> answers = {};
  late final List<QuestionPageData> questionPages;
  int currentPage = 0;
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    questionPages = [
      QuestionPageData('What is your age?', inputType: QuestionInputType.range, rangeMin: 10, rangeMax: 60, hint: "Select your age"),
      QuestionPageData('What is your height?', inputType: QuestionInputType.height),
      QuestionPageData('What is your weight (in kg)?', inputType: QuestionInputType.number, hint: "e.g. 60"),
      QuestionPageData('Are you sexually active?', inputType: QuestionInputType.choice, choices: ["Yes", "No"]),
      QuestionPageData('When did your last period start?', inputType: QuestionInputType.date),
      QuestionPageData('How long does your period usually last?', inputType: QuestionInputType.number, hint: "e.g. 5 days"),
      QuestionPageData('How long is your average cycle (from the start of one period to the start of the next)?', inputType: QuestionInputType.number, hint: "e.g. 28 days"),
      QuestionPageData('Are your cycles regular or irregular?', inputType: QuestionInputType.choice, choices: ["Regular", "Irregular"]),
      QuestionPageData('When did you first start menstruating (age at menarche)?', inputType: QuestionInputType.number, hint: "e.g. 13"),
      QuestionPageData('What symptoms do you typically experience during your period?', inputType: QuestionInputType.multichoice, choices: ["Cramps", "Headaches", "Mood swings", "Bloating", "Fatigue", "Breast tenderness", "Other"]),
      QuestionPageData('Do you experience any symptoms before your period starts (PMS)?', inputType: QuestionInputType.choice, choices: ["Yes", "No"]),
      QuestionPageData('How would you rate the intensity of your menstrual flow?', inputType: QuestionInputType.choice, choices: ["Light", "Normal", "Heavy"]),
      QuestionPageData('Do you take any medications (related to your cycle or otherwise)?', inputType: QuestionInputType.text, hint: "List medications if any"),
      QuestionPageData('Do you have any diagnosed reproductive health conditions (PCOS, endometriosis, thyroid disorder, etc.)?', inputType: QuestionInputType.text, hint: "List conditions if any"),
      QuestionPageData('Are you currently using any form of contraception/birth control? (Type and duration)', inputType: QuestionInputType.text, hint: "Write details if any"),
      QuestionPageData('What are your main goals for using this app?', inputType: QuestionInputType.multichoice, choices: ["Cycle tracking", "Fertility/pregnancy planning", "Symptom relief", "General health", "Other"]),
      QuestionPageData('Are you trying to conceive, avoid pregnancy, or neither?', inputType: QuestionInputType.choice, choices: ["Conceive", "Avoid pregnancy", "Neither"]),
      QuestionPageData('Would you like to receive personalized recommendations based on your answers?', inputType: QuestionInputType.choice, choices: ["Yes", "No"]),
      QuestionPageData('Are you comfortable with tracking additional health data (mood, sleep, activity, etc.)?', inputType: QuestionInputType.choice, choices: ["Yes", "No"]),
    ];
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _nextPage() {
    setState(() {
      answers[currentPage] = _controller.text;
      _controller.clear();
      currentPage += 1;
    });
  }

  void _skipSurvey() {
    setState(() {
      currentPage = questionPages.length;
    });
  }

  void _finishSurvey() {
    answers[currentPage] = _controller.text;
    setState(() {
      currentPage = questionPages.length;
    });
  }

  void _prevPage() {
    if (currentPage > 0) {
      setState(() {
        currentPage -= 1;
        _controller.text = answers[currentPage]?.toString() ?? "";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (currentPage >= questionPages.length) {
      return Scaffold(
        backgroundColor: babyPink,
        appBar: AppBar(
          title: const Text("MyPeriodDiary"),
          backgroundColor: babyPink,
          elevation: 0,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "Thank you for your Response ! ",
                style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: 170,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: babyPink,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: () {
                    // Go to Calendar/root functionality
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (_) => const RootPage()),
                    );
                  },
                  child: const Text(
                    'Go to HomePage',
                    style: TextStyle(
                      color: babyPink,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    final page = questionPages[currentPage];
    return Scaffold(
      backgroundColor: babyPink,
      appBar: AppBar(
        title: const Text("MyPeriodDiary"),
        backgroundColor: babyPink,
        elevation: 0,
        leading: currentPage > 0
            ? IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: _prevPage,
        )
            : null,
        actions: [
          TextButton(
            onPressed: _skipSurvey,
            child: const Text("Skip", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28.0, vertical: 24.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    page.question,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 22,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  _buildInput(page),
                  const SizedBox(height: 28),
                  if (page.inputType == QuestionInputType.date ||
                      page.inputType == QuestionInputType.choice ||
                      page.inputType == QuestionInputType.multichoice ||
                      page.inputType == QuestionInputType.range ||
                      page.inputType == QuestionInputType.height)
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        onPressed: answers.containsKey(currentPage) && (answers[currentPage] != null && answers[currentPage].toString().isNotEmpty)
                            ? () {
                          if (currentPage == questionPages.length - 1) {
                            _finishSurvey();
                          } else {
                            setState(() {
                              currentPage += 1;
                              _controller.clear();
                            });
                          }
                        }
                            : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: babyPink,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          elevation: 2,
                        ),
                        child: Text(
                          currentPage == questionPages.length - 1 ? "Finish" : "Next",
                          style: const TextStyle(
                            color: babyPink,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                  if (page.inputType == QuestionInputType.text || page.inputType == QuestionInputType.number)
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        onPressed: () {
                          if (_controller.text.trim().isEmpty) return;
                          if (currentPage == questionPages.length - 1) {
                            _finishSurvey();
                          } else {
                            _nextPage();
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: babyPink,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          elevation: 2,
                        ),
                        child: Text(
                          currentPage == questionPages.length - 1 ? "Finish" : "Next",
                          style: const TextStyle(
                            color: babyPink,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInput(QuestionPageData page) {
    if (page.inputType == QuestionInputType.date) {
      return DateInputField(
        initialValue: answers[currentPage]?.toString(),
        onDateSelected: (date) {
          setState(() {
            answers[currentPage] = date;
          });
        },
      );
    } else if (page.inputType == QuestionInputType.choice) {
      return ChoiceInputField(
        choices: page.choices!,
        initialValue: answers[currentPage]?.toString(),
        onChoiceSelected: (choice) {
          setState(() {
            answers[currentPage] = choice;
          });
        },
      );
    } else if (page.inputType == QuestionInputType.multichoice) {
      return MultiChoiceInputField(
        choices: page.choices!,
        selectedValues: answers[currentPage] ?? [],
        onChanged: (selectedList) {
          setState(() {
            answers[currentPage] = selectedList;
          });
        },
      );
    } else if (page.inputType == QuestionInputType.range) {
      return RangeInputField(
        min: page.rangeMin ?? 0,
        max: page.rangeMax ?? 100,
        value: answers[currentPage] ?? (page.rangeMin ?? 0),
        onChanged: (v) {
          setState(() {
            answers[currentPage] = v;
          });
        },
      );
    } else if (page.inputType == QuestionInputType.height) {
      return HeightInputField(
        feet: (answers[currentPage]?['feet']) ?? 5,
        inches: (answers[currentPage]?['inches']) ?? 0,
        onChanged: (feet, inches) {
          setState(() {
            answers[currentPage] = {'feet': feet, 'inches': inches};
          });
        },
      );
    } else if (page.inputType == QuestionInputType.number) {
      return TextField(
        controller: _controller,
        keyboardType: TextInputType.number,
        style: const TextStyle(color: Colors.white, fontSize: 18),
        decoration: InputDecoration(
          hintText: page.hint,
          hintStyle: const TextStyle(color: Colors.white60),
          filled: true,
          fillColor: babyPink.withAlpha(180),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Colors.white24),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Colors.white),
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        ),
      );
    } else {
      return TextField(
        controller: _controller,
        style: const TextStyle(color: Colors.white, fontSize: 18),
        decoration: InputDecoration(
          hintText: page.hint,
          hintStyle: const TextStyle(color: Colors.white60),
          filled: true,
          fillColor: babyPink.withAlpha(180),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Colors.white24),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Colors.white),
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        ),
      );
    }
  }
}
