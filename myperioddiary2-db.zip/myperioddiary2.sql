-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 07, 2025 at 06:00 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myperioddiary2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `email`, `password_hash`) VALUES
(1, 'priyajha1528@gmail.com', '$2y$10$YRprF0oRNClRWH880G7uC.6aNGaCLQDpuyHkPPaw6mgof8hl4Ae3S');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `answer_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `choice` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `calendar`
--

CREATE TABLE `calendar` (
  `calendar_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cycle_start_date` date NOT NULL,
  `cycle_end_date` date NOT NULL,
  `cycle_length` int(11) NOT NULL,
  `period_length` int(11) NOT NULL,
  `ovulation_date` date DEFAULT NULL,
  `fertile_window` varchar(50) DEFAULT NULL,
  `flow_intensity` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `calendar`
--

INSERT INTO `calendar` (`calendar_id`, `user_id`, `cycle_start_date`, `cycle_end_date`, `cycle_length`, `period_length`, `ovulation_date`, `fertile_window`, `flow_intensity`) VALUES
(19, 2, '2025-07-10', '2025-08-07', 28, 7, NULL, NULL, NULL),
(21, 1, '2025-07-10', '2025-08-07', 28, 5, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cycle_days`
--

CREATE TABLE `cycle_days` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `phase` enum('Menstrual','Follicular','Ovulation','Luteal') NOT NULL,
  `is_period_day` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `foodreceipe`
--

CREATE TABLE `foodreceipe` (
  `recipe_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foodreceipe`
--

INSERT INTO `foodreceipe` (`recipe_id`, `title`, `description`) VALUES
(1, 'Day 1: Ginger-Turmeric Tea', 'Warm anti-inflammatory tea to reduce cramps. Boil water with 1 inch ginger, 1/2 tsp turmeric, pinch black pepper, and honey. Sip warm.'),
(2, 'Day 1: Moong Dal Khichdi', 'Light, easy-to-digest, iron-rich meal. Cook yellow moong dal + rice + cumin + turmeric + salt in ghee. Garnish with coriander.'),
(3, 'Day 2: Ragi Porridge', 'Calcium and iron-rich breakfast. Mix ragi flour with water + jaggery + milk (optional). Cook until thick.'),
(4, 'Day 2: Steamed Veggies + Beetroot Soup', 'Detox meal. Steam carrots, broccoli, spinach. Beetroot soup helps replenish iron.'),
(5, 'Day 3: Palak Paneer with Multigrain Roti', 'Iron, calcium & protein combo. Blended spinach with garlic, cooked with paneer. Serve with multigrain roti.'),
(6, 'Day 3: Dates & Banana Smoothie', 'Energy drink. Blend 1 banana + 2 dates + milk/yogurt + chia seeds. Good for post-bleeding fatigue.'),
(7, 'Day 4: Lentil Salad', 'Protein & fiber rich. Mix cooked green moong dal + tomatoes + onion + lemon + olive oil.'),
(8, 'Day 4: Sweet Potato Chaat', 'Rich in complex carbs & iron. Boiled sweet potato, tossed with lemon, rock salt, cumin, and mint.'),
(9, 'Day 5: Oats Upma with Veggies', 'Healthy fiber-rich breakfast. Roast oats + cook with mustard, curry leaves, carrots, and peas.'),
(10, 'Day 5: Turmeric Milk + Dry Fruits', 'Warming drink. Boil milk with turmeric, saffron, and add chopped almonds, dates, and a little jaggery.');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `medicine_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `medicine_name` varchar(255) NOT NULL,
  `dosage` varchar(100) DEFAULT NULL,
  `frequency` varchar(100) DEFAULT NULL,
  `symptoms` varchar(255) DEFAULT NULL,
  `sideeffect` varchar(255) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `id` int(11) NOT NULL,
  `medicine_name` varchar(255) NOT NULL,
  `dosage` varchar(255) NOT NULL,
  `frequency` varchar(255) NOT NULL,
  `symptoms` text NOT NULL,
  `sideeffect` text NOT NULL,
  `timestamp` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`id`, `medicine_name`, `dosage`, `frequency`, `symptoms`, `sideeffect`, `timestamp`) VALUES
(1, 'Ibuprofen (Advil, Motrin IB)', '200–400 mg (OTC) or up to 800 mg', 'Every 6–8 hours as needed, for 2–3 days', 'Menstrual cramps, lower abdominal pain, headache, heavy bleeding', 'Upset stomach, nausea, heartburn, dizziness, kidney issues', '2025-08-03 01:12:00'),
(2, 'Naproxen (Aleve)', '250–500 mg', 'Every 8–12 hours, for 2–3 days', 'Menstrual cramps, heavy bleeding', 'Stomach upset, heartburn, headache, drowsiness', '2025-08-03 01:12:00'),
(3, 'Tranexamic Acid (Lysteda)', '650–1,300 mg', 'Three times daily, up to 5 days', 'Heavy menstrual bleeding', 'Nausea, diarrhea, headache, muscle cramps', '2025-08-03 01:12:00'),
(4, 'Mefenamic Acid (Ponstel)', '500 mg first dose, then 250 mg', 'Every 6 hours as needed, for 2–3 days', 'Menstrual cramps, heavy bleeding', 'Nausea, diarrhea, stomach pain, dizziness', '2025-08-03 01:12:00'),
(5, 'Combined Oral Contraceptive Pills', 'Varies (e.g., 0.035 mg ethinyl estradiol/0.25 mg norgestimate)', 'One pill daily, start day 1 or as directed', 'Irregular periods, heavy bleeding, painful periods, PMS', 'Nausea, breast tenderness, breakthrough bleeding, mood changes', '2025-08-03 01:12:00'),
(6, 'Norethisterone (Primolut N)', '5 mg', 'Three times daily, start 3 days before period or day 1', 'Heavy/irregular periods, period delay', 'Breakthrough bleeding, breast tenderness, nausea, headache', '2025-08-03 01:12:00'),
(7, 'Medroxyprogesterone Acetate (Provera)', '2.5–10 mg', 'Once daily for 5–10 days, start day 1 or as directed', 'Irregular periods, heavy bleeding, endometriosis', 'Bloating, mood swings, breast tenderness, irregular bleeding', '2025-08-03 01:12:00');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `notification_type` varchar(100) NOT NULL,
  `medicine_id` int(11) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `repeat_frequency` varchar(50) DEFAULT NULL,
  `delivery_method` varchar(50) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `user_id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `period_suggestions`
--

CREATE TABLE `period_suggestions` (
  `day` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `nutrition` text NOT NULL,
  `selfcare` text NOT NULL,
  `exercise` text NOT NULL,
  `medtips` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `period_suggestions`
--

INSERT INTO `period_suggestions` (`day`, `title`, `nutrition`, `selfcare`, `exercise`, `medtips`) VALUES
(1, 'Day 1: First Day of Period (Menstrual Flow Begins)', 'Focus on iron-rich foods to replenish lost iron: spinach, kale, red meat, lentils, tofu, pumpkin seeds.\r\nInclude vitamin C-rich foods (like oranges or bell peppers) to help iron absorption.\r\nStay well hydrated with warm fluids like ginger or chamomile tea.', 'Use a heating pad on the lower abdomen to relieve cramps.\r\nPractice gentle breathing or mindfulness to manage discomfort.', 'Gentle yoga poses like Child’s Pose, Cat-Cow stretch, or Reclining Twist. Avoid strenuous activities.', 'Use over-the-counter pain relievers like Ibuprofen or Naproxen as prescribed.\r\nAvoid caffeine and alcohol as they can worsen cramps.'),
(2, 'Day 2: Peak Menstrual Flow', 'Continue iron-rich and nutrient-dense foods.\r\nAdd magnesium-rich foods (nuts, whole grains, leafy greens).\r\nSnack on bananas for potassium to balance electrolytes and reduce bloating.', 'Maintain good hygiene; change pads/tampons regularly.\r\nContinue using warm compresses as needed.', 'Engage in restorative yoga or mild stretching to ease muscle tension.', 'Stay hydrated; warm water helps ease cramping.\r\nAvoid cold foods or drinks that may increase uterine contractions.'),
(3, 'Day 3: Mid Menstrual Phase', 'Add vitamin B6-rich foods (chickpeas, oats, poultry) for mood support.\r\nInclude probiotics (yogurt, kefir) for gut health.\r\nKeep hydrated with water or herbal teas.', 'Use aromatherapy with calming scents like lavender or peppermint.\r\nApply gentle massage on lower back and abdomen for pain relief.', 'Try moderate yoga: Seated Forward Fold, Happy Baby Pose.', 'If cramps ease, reduce pain medications.\r\nTry natural teas like peppermint or raspberry leaf for more support.'),
(4, 'Day 4: Light Flow/End of Menstrual Phase', 'Balance your diet with fiber (whole grains, fruits) to prevent constipation.\r\nAdd antioxidant foods (berries, green tea) for cellular repair.', 'Keep warm and rest as needed.\r\nDo light walks or gentle movement if comfortable.', 'Begin gentle cardio (walking or swimming) if energy returns.', 'If discomfort subsides, medication may not be needed.\r\nMonitor your energy and mood as your cycle transitions.'),
(5, 'Day 5: Spotting/Transition Phase', 'Maintain hydration and continue nutrient-rich meals.\r\nAdd healthy omega-3s (flaxseed, walnuts, fatty fish) to reduce inflammation.', 'Focus on mental health; plan and reflect for the next cycle phase.\r\nConsider journaling symptoms or mood changes.', 'Return to moderate movement (yoga, walk); get ready for more activity in the follicular phase.', 'Prioritize rest, fluid intake, and menstrual tracking.');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `profileID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `QuestionID` int(11) DEFAULT NULL,
  `CalenderID` int(11) DEFAULT NULL,
  `Data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`Data`)),
  `status` enum('current','absolute') NOT NULL DEFAULT 'current'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`profileID`, `UserID`, `QuestionID`, `CalenderID`, `Data`, `status`) VALUES
(1, 1, NULL, NULL, '{\"name\":\"\",\"dob\":\"2002-01-15\",\"email\":\"priyajhaguriya@gmail.com\",\"height_feet\":5,\"height_inches\":0,\"weight\":\"80\",\"allergies\":\"no\",\"last_period\":\"\",\"period_length\":5,\"cycle_length\":28,\"irregularity\":\"regular\",\"symptoms\":[],\"medications\":\"meftal\",\"activity\":\"nothing\",\"notes\":\"nothing\",\"notifications\":[],\"custom_reminder\":\"to take medicine\"}', 'current');

-- --------------------------------------------------------

--
-- Table structure for table `questionnaire`
--

CREATE TABLE `questionnaire` (
  `question_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `question` varchar(500) NOT NULL,
  `answer` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questionnaire`
--

INSERT INTO `questionnaire` (`question_id`, `user_id`, `question`, `answer`) VALUES
(1, 1, 'What is your age?', '24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `middle_name`, `last_name`, `dob`, `email`, `phone`, `address`, `password`, `avatar`) VALUES
(1, 'priya', 'kumari', 'jha', '2002-01-15', 'priyajhaguriya@gmail.com', '9800917189', 'Biratnagar', '$2y$10$/jkQZGq60ysc57oprr6g4e5fND.mZuFQYJh.rHIQXrJKhEEbjQKWi', 'avatar_688eefa02f547.jpg'),
(2, 'Rejina', '', 'Agrawal', '2004-06-04', 'reginaagrawal200@gmail.com', '9827335786', 'Biratnagar', '$2y$10$Fg0j.7nanjJRrMPHro78i.uOSGV26qGhli.Y8UmfzWQ78b41puJBq', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `yogatips`
--

CREATE TABLE `yogatips` (
  `yoga_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image_path` varchar(500) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `yogatips`
--

INSERT INTO `yogatips` (`yoga_id`, `name`, `image_path`, `description`) VALUES
(1, 'Child’s Pose (Balasana)', '../yoga/images/childpose.png', 'Relieves cramps, soothes lower back, relaxes pelvic area. Best for cramping and anxiety.'),
(2, 'Cat-Cow (Marjaryasana-Bitilasana)', '../yoga/images/catcow.png', 'Gently massages uterus and belly, eases backache, good for mild discomfort.'),
(3, 'Reclining Twist (Supta Matsyendrasana)', '../yoga/images/reclinedtwist.png', 'Relieves lower back tension, helps digestion, aids bloating. Best for pain relief.'),
(4, 'Seated Forward Fold (Paschimottanasana)', '../yoga/images/Seated Forward Fold.png', 'Calms anxiety & mild cramps, stretches spine and hamstrings.'),
(5, 'Happy Baby Pose (Ananda Balasana)', '../yoga/images/HappyBabyPose.png', 'Opens hips, relieves pelvic fatigue/pressure. Good for heavy flow days.'),
(6, 'Supported Bridge Pose (Setu Bandha Sarvangasana)', '../yoga/images/SupportedBridgePose.png', 'Mild inversion with prop; relieves period fatigue and gently tones lower abdomen.'),
(7, 'Reclining Bound Angle (Supta Baddha Konasana)', '../yoga/images/RecliningBoundAngle.png', 'Reduces period bloating and cramps, calms stress, good for heaviness.'),
(8, 'Legs up the Wall (Viparita Karani)', '../yoga/images/LegsUpTheWall.png', 'Alleviates leg heaviness, eases fatigue from heavy flow; avoid if flow is very heavy.'),
(9, 'Sphinx Pose (Salamba Bhujangasana)', '../yoga/images/SphinxPose.png', 'Gentle backbend, relieves tension and mild ache in lower back.'),
(10, 'Butterfly Pose (Baddha Konasana)', '../yoga/images/ButterflyPose.png', 'Stretches inner thighs, releases pelvic tension. Best for day 2-4 discomfort.'),
(11, 'Supine Pigeon (Eye of the Needle)', '../yoga/images/SupinePigeon.png', 'Eases sciatic pain and lower back tightness that may flare with hormonal shifts.'),
(12, 'Supported Fish Pose (Matsyasana Variation)', '../yoga/images/SupportedFishPose.png', 'Opens the chest/abdomen, lessens fatigue and mild breast tenderness.'),
(13, 'Knee-to-Chest (Apanasana)', '../yoga/images/knee-to-chest.png', 'Relieves bloating, mild gas pain, and calms menstrual abdominal tension.'),
(14, 'Savasana (Corpse Pose)', '../yoga/images/Savasana.png', 'Encourages full relaxation, restores energy, lowers anxiety and mood swings.'),
(15, 'Thread the Needle Pose', '../yoga/images/ThreadTheNeedlePose.png', 'Releases tension in shoulders/upper back, helps with upper body aches due to period posture.'),
(16, 'Savasana(Corpse Pose)', 'C:\\xampp\\htdocs\\myperioddiary\\yoga\\images\\Savasana.png', 'encourages full relaxation ,re');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `answer`
--
ALTER TABLE `answer`
  ADD PRIMARY KEY (`answer_id`),
  ADD KEY `question_id` (`question_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `calendar`
--
ALTER TABLE `calendar`
  ADD PRIMARY KEY (`calendar_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `cycle_days`
--
ALTER TABLE `cycle_days`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`date`);

--
-- Indexes for table `foodreceipe`
--
ALTER TABLE `foodreceipe`
  ADD PRIMARY KEY (`recipe_id`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`medicine_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `medicine_id` (`medicine_id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `period_suggestions`
--
ALTER TABLE `period_suggestions`
  ADD PRIMARY KEY (`day`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`profileID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `QuestionID` (`QuestionID`),
  ADD KEY `CalenderID` (`CalenderID`);

--
-- Indexes for table `questionnaire`
--
ALTER TABLE `questionnaire`
  ADD PRIMARY KEY (`question_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `yogatips`
--
ALTER TABLE `yogatips`
  ADD PRIMARY KEY (`yoga_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `answer`
--
ALTER TABLE `answer`
  MODIFY `answer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `calendar`
--
ALTER TABLE `calendar`
  MODIFY `calendar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `cycle_days`
--
ALTER TABLE `cycle_days`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `foodreceipe`
--
ALTER TABLE `foodreceipe`
  MODIFY `recipe_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `medicine_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `profileID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `questionnaire`
--
ALTER TABLE `questionnaire`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `yogatips`
--
ALTER TABLE `yogatips`
  MODIFY `yoga_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answer`
--
ALTER TABLE `answer`
  ADD CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questionnaire` (`question_id`),
  ADD CONSTRAINT `answer_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `calendar`
--
ALTER TABLE `calendar`
  ADD CONSTRAINT `calendar_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `cycle_days`
--
ALTER TABLE `cycle_days`
  ADD CONSTRAINT `cycle_days_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `medicine`
--
ALTER TABLE `medicine`
  ADD CONSTRAINT `medicine_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notification_ibfk_2` FOREIGN KEY (`medicine_id`) REFERENCES `medicine` (`medicine_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `notification_ibfk_3` FOREIGN KEY (`question_id`) REFERENCES `questionnaire` (`question_id`) ON DELETE SET NULL;

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `fk_password_resets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `profile_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `profile_ibfk_2` FOREIGN KEY (`QuestionID`) REFERENCES `questionnaire` (`question_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `profile_ibfk_3` FOREIGN KEY (`CalenderID`) REFERENCES `calendar` (`calendar_id`) ON DELETE SET NULL;

--
-- Constraints for table `questionnaire`
--
ALTER TABLE `questionnaire`
  ADD CONSTRAINT `questionnaire_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
